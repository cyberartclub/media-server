/**
 * Storage-agnostic block tree types for `@eclosion-tech/pulp`.
 *
 * Pear's SpacetimeDB `ComponentNode` rows satisfy these shapes
 * structurally — the adapter layer maps substrate rows to `BlockTree`
 * without copying.
 */

export type BlockId = bigint;

/** A single node in a block tree surface. */
export type BlockNode = {
  id: BlockId;
  surfaceId: BlockId;
  parentId?: BlockId | null;
  componentType: string;
  props: string;
  order: number | bigint;
  updatedAt?: { microsSinceUnixEpoch: BlockId };
  deletedAt?: unknown | null;
};

/** Declaration-side metadata for a block type (Pear: `ComponentTypeDefinition`). */
export type BlockTypeDefinition = {
  componentType: string;
  propSchema: string;
  displayName?: string;
  acceptsChildren: boolean;
  hasYjsState?: boolean;
  isBuiltin?: boolean;
};

/** Per-block Yjs blob when the type has `hasYjsState`. */
export type BlockYjsState = {
  componentNodeId: BlockId;
  data: Uint8Array;
  updatedAt?: { microsSinceUnixEpoch: BlockId };
};

export type BlockTree = {
  root: BlockNode | null;
  byId: Map<BlockId, BlockNode>;
  byParent: Map<BlockId | null, BlockNode[]>;
  defs: Map<string, BlockTypeDefinition>;
  yjs: Map<BlockId, BlockYjsState>;
  loading: boolean;
};

export type PropValidationResult = import("./componentProps").ValidationResult;

export type PulpMutations = {
  insertBlock: (args: {
    parentId: BlockId;
    componentType: string;
    propsJson: string;
    afterSiblingId?: BlockId;
  }) => void | Promise<void>;
  deleteBlock: (args: { componentId: BlockId }) => void | Promise<void>;
  moveBlock: (args: {
    componentId: BlockId;
    newParentId: BlockId;
    afterSiblingId?: BlockId;
  }) => void | Promise<void>;
  updateBlockProps: (args: {
    componentId: BlockId;
    propsJson: string;
  }) => void | Promise<void>;
  saveYjsState: (args: {
    componentId: BlockId;
    data: Uint8Array;
  }) => void | Promise<void>;
  /** Soft-undelete — Pear: `restore_component`. Optional; delete undo falls back to re-insert. */
  restoreBlock?: (args: { componentId: BlockId }) => void | Promise<void>;
};

export type PulpConfig = {
  /** IndexedDB namespace prefix, e.g. `pear:my-workspace`. */
  idbPrefix: string;
  validateProps?: (
    props: string,
    schema: string,
  ) => PropValidationResult;
  /** Override slash / turn-into menu items (Pear sprint 4+). */
  slashItems?: import("./SlashMenu").SlashMenuItem[];
  /** Optional internal destinations for rich-text link insertion. */
  linkTargets?: Array<{
    id: string;
    label: string;
    href: string;
    subtitle?: string;
  }>;
  /**
   * Called when the user clicks "Comment" in the block menu.
   * The host app is responsible for creating the anchored thread.
   */
  onCommentBlock?: (nodeId: BlockId) => void;
  /**
   * Ephemeral read-only render mode. When set, the tree renders with no
   * editor machinery: no block chrome (drag / insert / menu), and leaf
   * editors (RichText, Heading) render their static HTML body instead of
   * mounting ProseMirror / IndexedDB. Used by `<BlockView>` for custom-view
   * and generative-chat rendering. Mutations are never invoked in this mode.
   */
  readOnly?: boolean;
  /**
   * Supplies rows to `Repeater` nodes (ADR D1). Pulp owns materialization and
   * virtual-node rendering; the host owns storage, so it maps a
   * `DataSourceConfig` onto its own subscriptions. Absent means repeaters
   * render their template with a "no resolver configured" notice rather than
   * failing — a host that doesn't do data binding still renders the tree.
   */
  queryResolver?: import("./repeater/dataSource").QueryResolver;
  /** Host storage and URL adapter for editable references to source block subtrees. */
  references?: import("./reference/types").ReferenceAdapter;
};

export type PulpContextValue = {
  tree: BlockTree;
  config: PulpConfig;
} & PulpMutations;

/** Minimal insert event for the surface focus coordinator. */
export type BlockInsertEvent = {
  id: BlockId;
  surfaceId: BlockId;
  parentId?: BlockId | null;
  deletedAt?: unknown | null;
};

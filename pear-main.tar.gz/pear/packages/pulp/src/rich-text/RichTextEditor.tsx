"use client";

import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type RefObject,
} from "react";
import * as Y from "yjs";
import { IndexeddbPersistence } from "y-indexeddb";
import { useSurfaceSelectionOptional } from "../selection/SurfaceSelectionProvider";
import { textSelectionPlugin } from "../selection/textSelectionPlugin";
import { EditorState } from "prosemirror-state";
import { EditorView } from "prosemirror-view";
import { keymap } from "prosemirror-keymap";
import {
  baseKeymap,
  chainCommands,
  exitCode,
  toggleMark,
} from "prosemirror-commands";
import {
  ySyncPlugin,
} from "y-prosemirror";
import { textUndoManager, textUndoPlugin } from "../undo/textUndo";
import {
  richTextSchema,
  PROSEMIRROR_FRAGMENT_KEY,
} from "./richTextSchema";
import { usePulp } from "../context/PulpProvider";
import { useSurfaceFocus } from "../focus/SurfaceFocusProvider";
import {
  applyEditorFocus,
  editorHasFocus,
  type FocusPlacement,
} from "../focus/SurfaceFocusCoordinator";
import { focusDebug, idStr } from "../focus/focusDebug";
import { useSurfaceUndo } from "../undo/SurfaceUndoProvider";
import { FormattingToolbar, type BlockToolbarActions } from "./FormattingToolbar";
import {
  handleRichTextArrowDown,
  handleRichTextArrowUp,
  handleRichTextBackspace,
  handleRichTextEnter,
  handleRichTextShiftTab,
  handleRichTextTab,
  inlineMarksDisabled,
  type EditorSurfaceMode,
} from "./richTextKeymap";
import {
  markdownShortcutPlugin,
  type MarkdownShortcut,
} from "./markdownInputRules";
import {
  slashMenuPlugin,
  type SlashSession,
} from "./slashMenuPlugin";
import type { SlashMenuItem } from "../SlashMenu";

export type { EditorSurfaceMode } from "./richTextKeymap";

/** Cadence — see `docs/PEAR_WEB_RENDERER.md` § Editor stack — Save cycle. */
const SAVE_INTERVAL_MS = 30_000;

const EDITOR_PROSE_DEFAULT =
  "my-2 text-neutral-900 dark:text-neutral-100 leading-relaxed [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-2 [&_.ProseMirror_a]:underline [&_.ProseMirror_code]:rounded [&_.ProseMirror_code]:bg-neutral-100 dark:[&_.ProseMirror_code]:bg-neutral-800 [&_.ProseMirror_code]:px-1 [&_.ProseMirror_code]:py-0.5 [&_.ProseMirror_strong]:font-semibold [&_.ProseMirror_em]:italic [&_.ProseMirror_u]:underline [&_.ProseMirror_s]:line-through";

const EDITOR_PROSE_LIST_ITEM =
  "my-0 text-neutral-900 dark:text-neutral-100 leading-normal [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0 [&_.ProseMirror_a]:underline [&_.ProseMirror_code]:rounded [&_.ProseMirror_code]:bg-neutral-100 dark:[&_.ProseMirror_code]:bg-neutral-800 [&_.ProseMirror_code]:px-1 [&_.ProseMirror_code]:py-0.5 [&_.ProseMirror_strong]:font-semibold [&_.ProseMirror_em]:italic [&_.ProseMirror_u]:underline [&_.ProseMirror_s]:line-through";

const HEADING_EDITOR_PROSE: Record<number, string> = {
  1: "my-2 text-4xl font-bold leading-tight text-neutral-900 dark:text-neutral-100 [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0",
  2: "my-2 text-3xl font-bold leading-tight text-neutral-900 dark:text-neutral-100 [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0",
  3: "my-2 text-2xl font-semibold leading-tight text-neutral-900 dark:text-neutral-100 [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0",
  4: "my-2 text-xl font-semibold leading-tight text-neutral-900 dark:text-neutral-100 [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0",
  5: "my-2 text-lg font-medium leading-tight text-neutral-900 dark:text-neutral-100 [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0",
  6: "my-2 text-base font-medium leading-tight text-neutral-900 dark:text-neutral-100 [&_.ProseMirror]:outline-none [&_.ProseMirror_p]:my-0",
};

/**
 * Live `RichText` editor — sprint 2 of the web renderer.
 *
 * Mounts a `y-prosemirror` view on top of the per-component Y.Doc. Wires:
 *   - IndexedDB persistence (`y-indexeddb`) per component, namespace
 *     `pear:{idbNamespace}:component:{componentId}`
 *   - 30s debounced `save_component_yjs_state` push (local-origin only;
 *     remote-origin updates skip the save loop to prevent echo)
 *   - Base + Pear keybindings (Mod-Z/Mod-Y undo via y-prosemirror's stack;
 *     Mod-B/I/U/Shift-S inline mark toggles; Mod-` inline code; Shift-Enter
 *     hard-break)
 *
 * Mounted by `<RichText>` only when the block is in the viewport (or has
 * focus) per § Performance — Viewport-aware editor mounting. The static
 * HTML path covers off-screen blocks.
 *
 * AI-origin updates (sprint 7 — AI authoring surface) will land with
 * `origin === "ai"` and behave identically to remote-origin from this
 * view's perspective.
 */
export function RichTextEditor({
  doc,
  componentId,
  placeholder,
  textDensity = "default",
  surfaceMode = { kind: "body" },
  shouldClaimFocus,
  onFocus,
  onBlur,
  onSplit,
  onDeleteSelf,
  onMergeWithPrev,
  onSlashSessionChange,
  onSlashNavigate,
  onSlashCommit,
  onSlashDismiss,
  suppressSaveRef,
  onNavigatePrev,
  onNavigateNext,
  onIndent,
  onOutdent,
  bindFocus,
  blockActions,
  markdownShortcuts,
  onMarkdownShortcut,
  onPaste,
  onEscape,
}: {
  doc: Y.Doc;
  componentId: bigint;
  placeholder?: string;
  /** Compact prose for list-item rows (no paragraph margins). */
  textDensity?: "default" | "listItem";
  /** Body vs heading surface — headings use title typography and plain text only. */
  surfaceMode?: EditorSurfaceMode;
  /**
   * Called once on editor mount to claim autofocus after an insert.
   * Returns caret placement when this block was the insert target.
   */
  shouldClaimFocus?: () => FocusPlacement | null;
  onFocus?: () => void;
  onBlur?: () => void;
  /**
   * Called on **Enter** anywhere in the doc — at end, in middle, at
   * start. Caller is expected to split the doc at the cursor (cut
   * suffix into a new sibling `RichText`) and arm autofocus on the
   * new block. Receives the live view so the caller can read the
   * selection and dispatch transactions to truncate this doc. Returns
   * true if the gesture was claimed; false falls through to default
   * `splitBlock` (creates a new paragraph within this same RichText).
   */
  onSplit?: (view: EditorView) => boolean;
  /**
   * Called when the user presses Backspace at the start of an empty doc.
   * Caller is expected to dispatch `delete_component` for this node. If
   * absent (e.g. this is the only block on the surface), Backspace
   * falls through to its default behaviour (which is a no-op at pos 1
   * of an empty paragraph).
   */
  onDeleteSelf?: () => void;
  /**
   * Called on Backspace at the start of a **non-empty** doc. Caller is
   * expected to merge this block's content into the previous sibling's
   * RichText (Notion-style join) and delete this block. Receives the
   * live view so the caller can read this doc's content. Returns true
   * if the gesture was claimed; false falls through to default
   * Backspace (deletes one character).
   */
  onMergeWithPrev?: (view: EditorView) => boolean;
  /**
   * Inline slash menu — fired when a `/` session opens / updates / closes.
   * The `/` and query live in the doc; caller renders `<InlineSlashMenu>` at
   * `rect` and filters by `query`. Null closes the menu.
   */
  onSlashSessionChange?: (
    session: { query: string; from: number; rect: DOMRect } | null,
  ) => void;
  /** While the slash menu is open — move the highlighted item. */
  onSlashNavigate?: (direction: 1 | -1) => void;
  /** While the slash menu is open — commit the highlighted item. Returns true if claimed. */
  onSlashCommit?: () => boolean;
  /** While the slash menu is open — dismiss without inserting. */
  onSlashDismiss?: () => void;
  /**
   * When true, skip Yjs persistence — the block is being soft-deleted and
   * `save_component_yjs_state` would reject a deleted node.
   */
  suppressSaveRef?: RefObject<boolean>;
  /** ArrowUp at doc start — focus previous sibling (caret at end). */
  onNavigatePrev?: () => boolean;
  /** ArrowDown at doc end — focus next sibling (caret at start). */
  onNavigateNext?: () => boolean;
  /** Tab — nest block under previous sibling when supported. */
  onIndent?: () => boolean;
  /** Shift+Tab — unnest block to grandparent. */
  onOutdent?: () => boolean;
  /**
   * Parent registers the surface focus coordinator against this editor's
   * applyFocus fn — keeps static→live transitions able to reach a live view.
   */
  bindFocus?: (applyFocus: (placement: FocusPlacement) => void) => () => void;
  /** Block-level toolbar controls (type dropdown, nest/unnest). */
  blockActions?: BlockToolbarActions;
  /** Markdown prefix → block-type conversions (`- `, `# `, `[] `, …). */
  markdownShortcuts?: MarkdownShortcut[];
  /** Fired when a markdown shortcut matches; caller converts the block type. */
  onMarkdownShortcut?: (item: SlashMenuItem) => void;
  /**
   * Multi-block paste. Caller parses the clipboard and, if it splits into 2+
   * blocks, inserts them and returns true (paste consumed). Returns false to
   * fall through to ProseMirror's default inline paste (single block).
   */
  onPaste?: (data: { text: string; html: string }, view: EditorView) => boolean;
  /** Escape with no slash menu open — caller selects this block (block selection). */
  onEscape?: () => boolean;
}) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const viewRef = useRef<EditorView | null>(null);
  const idbRef = useRef<IndexeddbPersistence | null>(null);
  const { saveYjsState, config, tree } = usePulp();
  const focus = useSurfaceFocus();
  const textSelection = useSurfaceSelectionOptional()?.text;
  const { registerYjsUndoManager } = useSurfaceUndo();
  const idbPrefix = config.idbPrefix;
  const treeRef = useRef(tree);
  treeRef.current = tree;
  // Exposed to the floating toolbar so it can read the editor selection
  // and dispatch toggleMark commands. Lives in state (not ref) because the
  // toolbar is a separate React subtree and needs to re-render when the
  // view becomes available.
  const [view, setView] = useState<EditorView | null>(null);
  const [linkRequest, setLinkRequest] = useState(0);

  // Latest callback refs — the prosemirror keymap closes over the *first*
  // render's values, so we route through refs that we update on every
  // render. Keeps closure-captured Enter/Backspace logic in sync with
  // parent-component state without forcing the editor to re-mount.
  const onSplitRef = useRef(onSplit);
  const onDeleteSelfRef = useRef(onDeleteSelf);
  const onMergeWithPrevRef = useRef(onMergeWithPrev);
  const onSlashSessionChangeRef = useRef(onSlashSessionChange);
  const onSlashNavigateRef = useRef(onSlashNavigate);
  const onSlashCommitRef = useRef(onSlashCommit);
  const onSlashDismissRef = useRef(onSlashDismiss);
  /** True while a slash session is open — gates arrow/enter/escape routing. */
  const slashActiveRef = useRef(false);
  const onNavigatePrevRef = useRef(onNavigatePrev);
  const onNavigateNextRef = useRef(onNavigateNext);
  const onIndentRef = useRef(onIndent);
  const onOutdentRef = useRef(onOutdent);
  const shouldClaimFocusRef = useRef(shouldClaimFocus);
  const bindFocusRef = useRef(bindFocus);
  const surfaceModeRef = useRef(surfaceMode);
  const markdownShortcutsRef = useRef(markdownShortcuts);
  const onMarkdownShortcutRef = useRef(onMarkdownShortcut);
  const onPasteRef = useRef(onPaste);
  const onEscapeRef = useRef(onEscape);
  onSplitRef.current = onSplit;
  onDeleteSelfRef.current = onDeleteSelf;
  onMergeWithPrevRef.current = onMergeWithPrev;
  onSlashSessionChangeRef.current = onSlashSessionChange;
  onSlashNavigateRef.current = onSlashNavigate;
  onSlashCommitRef.current = onSlashCommit;
  onSlashDismissRef.current = onSlashDismiss;
  onNavigatePrevRef.current = onNavigatePrev;
  onNavigateNextRef.current = onNavigateNext;
  onIndentRef.current = onIndent;
  onOutdentRef.current = onOutdent;
  shouldClaimFocusRef.current = shouldClaimFocus;
  bindFocusRef.current = bindFocus;
  surfaceModeRef.current = surfaceMode;
  markdownShortcutsRef.current = markdownShortcuts;
  onMarkdownShortcutRef.current = onMarkdownShortcut;
  onPasteRef.current = onPaste;
  onEscapeRef.current = onEscape;

  useLayoutEffect(() => {
    if (!hostRef.current) return;

    const idbName = `${idbPrefix}:component:${componentId}`;
    const idb = new IndexeddbPersistence(idbName, doc);
    idbRef.current = idb;

    const fragment = doc.getXmlFragment(PROSEMIRROR_FRAGMENT_KEY);

    const undoManager = textUndoManager(doc);

    const state = EditorState.create({
      schema: richTextSchema,
      plugins: [
        ySyncPlugin(fragment),
        textUndoPlugin(undoManager),
        textSelectionPlugin(componentId, textSelection),
        markdownShortcutPlugin({
          getShortcuts: () => markdownShortcutsRef.current ?? [],
          onConvert: (item) => onMarkdownShortcutRef.current?.(item),
          isDisabled: () => surfaceModeRef.current.kind === "heading" || !onMarkdownShortcutRef.current,
        }),
        slashMenuPlugin({
          isDisabled: () => surfaceModeRef.current.kind === "heading" || !onSlashSessionChangeRef.current,
          onSessionChange: (session: (SlashSession & { view: EditorView }) | null) => {
            slashActiveRef.current = session != null;
            if (!session) {
              onSlashSessionChangeRef.current?.(null);
              return;
            }
            const coords = session.view.coordsAtPos(session.from);
            const rect = new DOMRect(
              coords.left,
              coords.top,
              0,
              coords.bottom - coords.top,
            );
            onSlashSessionChangeRef.current?.({
              query: session.query,
              from: session.from,
              rect,
            });
          },
        }),
        keymap({
          // Mod-Z / Mod-Shift-Z routed at surface level — § Cross-block undo.
          "Mod-b": (s, dispatch) => {
            if (inlineMarksDisabled(surfaceModeRef.current)) return false;
            return toggleMark(richTextSchema.marks.bold)(s, dispatch);
          },
          "Mod-i": (s, dispatch) => {
            if (inlineMarksDisabled(surfaceModeRef.current)) return false;
            return toggleMark(richTextSchema.marks.italic)(s, dispatch);
          },
          "Mod-u": (s, dispatch) => {
            if (inlineMarksDisabled(surfaceModeRef.current)) return false;
            return toggleMark(richTextSchema.marks.underline)(s, dispatch);
          },
          "Mod-Shift-s": (s, dispatch) => {
            if (inlineMarksDisabled(surfaceModeRef.current)) return false;
            return toggleMark(richTextSchema.marks.strike)(s, dispatch);
          },
          "Mod-`": (s, dispatch) => {
            if (inlineMarksDisabled(surfaceModeRef.current)) return false;
            return toggleMark(richTextSchema.marks.code)(s, dispatch);
          },
          "Mod-k": (s) => {
            if (inlineMarksDisabled(surfaceModeRef.current)) return false;
            if (s.selection.empty) return false;
            setLinkRequest((n) => n + 1);
            return true;
          },
          "Shift-Enter": chainCommands(exitCode, (s, dispatch) => {
            if (dispatch) {
              dispatch(
                s.tr
                  .replaceSelectionWith(richTextSchema.nodes.hard_break.create())
                  .scrollIntoView(),
              );
            }
            return true;
          }),
          // Block-boundary semantics — § Block chrome / Enter & Backspace.
          //
          // Enter unconditionally splits this RichText into two: the
          // prefix stays here, the suffix becomes a new RichText
          // sibling below. The "at-end" special-case from sprint 3a is
          // subsumed by this — at-end is just "suffix is empty". The
          // suffix Y.Doc is built by the caller and handed off via the
          // surface focus coordinator's initialDoc mechanism. Shift-
          // Enter is intercepted earlier as hard_break and never
          // reaches this handler.
          Enter: (s) => {
            if (slashActiveRef.current) {
              return onSlashCommitRef.current?.() ?? false;
            }
            focusDebug("Enter key → onSplit", { componentId: idStr(componentId) });
            return handleRichTextEnter(s, viewRef.current, {
              onSplit: onSplitRef.current,
            });
          },
          Escape: () => {
            if (slashActiveRef.current) {
              onSlashDismissRef.current?.();
              return true;
            }
            return onEscapeRef.current?.() ?? false;
          },
          Backspace: (s) => {
            return handleRichTextBackspace(s, viewRef.current, {
              onDeleteSelf: onDeleteSelfRef.current,
              onMergeWithPrev: onMergeWithPrevRef.current,
            });
          },
          ArrowUp: (s) => {
            if (slashActiveRef.current) {
              onSlashNavigateRef.current?.(-1);
              return true;
            }
            return handleRichTextArrowUp(s, viewRef.current, {
              onNavigatePrev: onNavigatePrevRef.current,
            });
          },
          ArrowDown: (s) => {
            if (slashActiveRef.current) {
              onSlashNavigateRef.current?.(1);
              return true;
            }
            return handleRichTextArrowDown(s, viewRef.current, {
              onNavigateNext: onNavigateNextRef.current,
            });
          },
          Tab: () => handleRichTextTab({ onIndent: onIndentRef.current }),
          "Shift-Tab": () =>
            handleRichTextShiftTab({ onOutdent: onOutdentRef.current }),
          // The inline slash menu (`/`) is handled by `slashMenuPlugin` via
          // `handleTextInput` — the keystroke enters the doc and forms the
          // live query. Arrow/Enter/Escape above route to the open menu.
        }),
        keymap(baseKeymap),
      ],
    });

    const editorView = new EditorView(hostRef.current, {
      state,
      dispatchTransaction(this: EditorView, tr) {
        this.updateState(this.state.apply(tr));
        textSelection?.onTransaction(componentId, tr);
      },
      attributes: {
        class:
          "outline-none min-h-[1.5em] " +
          (placeholder ? `[&:empty]:before:content-[attr(data-placeholder)] ` : ""),
        "data-placeholder": placeholder ?? "",
      },
      handlePaste: (pasteView, event) => {
        const fn = onPasteRef.current;
        if (!fn) return false;
        const cd = (event as ClipboardEvent).clipboardData;
        if (!cd) return false;
        return fn(
          { text: cd.getData("text/plain"), html: cd.getData("text/html") },
          pasteView,
        );
      },
      handleDOMEvents: {
        click: (_view, event) => {
          const anchor = (event.target as Element | null)?.closest?.("a[href]");
          if (!(anchor instanceof HTMLAnchorElement)) return false;
          const href = anchor.getAttribute("href");
          if (!href) return false;

          const mouse = event as MouseEvent;
          if (!mouse.metaKey && !mouse.ctrlKey) {
            event.preventDefault();
            return true;
          }

          event.preventDefault();
          navigateToHref(href);
          return true;
        },
        focus: () => {
          onFocus?.();
          // Do not ack here — focus fires synchronously during applyEditorFocus
          // and would clear the armed placement before handoff completes.
          return false;
        },
        blur: () => {
          onBlur?.();
          return false;
        },
      },
    });
    viewRef.current = editorView;
    setView(editorView);

    // Imperative focus handler — registered with the surface focus
    // coordinator so Backspace-into-previous / "Turn into…" / etc.
    // can imperatively focus this editor + place the caret at end.
    // Identical semantics to the claim-on-mount autofocus path
    // below, so users land in the same state regardless of which
    // gesture pulled them here.
    const focusSelf = (placement: FocusPlacement = "end") => {
      try {
        applyEditorFocus(editorView, placement, focus.consumeGoalX(componentId));
      } catch (err) {
        if (typeof console !== "undefined") {
          console.warn(
            `[RichTextEditor] focusSelf failed for component ${componentId}:`,
            err,
          );
        }
      }
    };
    const unregisterBindFocus = bindFocusRef.current?.(focusSelf);
    // Also register the live EditorView so sibling Backspace-merge
    // gestures can reach in and append content.
    const unregisterEditor = focus.registerEditor(componentId, editorView);
    const unregisterText = textSelection?.register(componentId, editorView);
    const unregisterUndo = registerYjsUndoManager(componentId, undoManager);

    const tryClaimAutofocus = () => {
      const claimPlacement = shouldClaimFocusRef.current?.();
      if (!claimPlacement) return false;
      sawFocusIntent = true;
      focusDebug("tryClaimAutofocus", {
        componentId: idStr(componentId),
        placement: claimPlacement,
      });
      focusSelf(claimPlacement);
      const hasFocus = editorHasFocus(editorView);
      focusDebug("tryClaimAutofocus: result", {
        componentId: idStr(componentId),
        hasFocus,
      });
      if (!hasFocus) return false;
      focusDebug("tryClaimAutofocus: ack", { componentId: idStr(componentId) });
      focus.ackFocus(componentId);
      return true;
    };

    const scheduleAutofocusRetries = () => {
      const retryDelaysMs = [0, 16, 50, 100, 200, 400, 700, 1000, 1500];
      for (const delayMs of retryDelaysMs) {
        focusRetryTimeouts.push(
          window.setTimeout(() => {
            if (viewRef.current !== editorView) return;
            tryClaimAutofocus();
          }, delayMs),
        );
      }
    };

    const focusRetryTimeouts: number[] = [];
    // Retries exist for the "intent aimed at this block but the view wasn't
    // focusable yet" race. Only schedule them when an attempt actually saw a
    // focus intent (the intent is consumed on match, so it can't be
    // re-checked) — without the gate, every block on a plain page open
    // scheduled 9 timers in the first 1.5s (ticket 14382).
    let sawFocusIntent = false;
    // Double rAF so we run after Strict Mode remount + parent registerFocusable.
    if (typeof requestAnimationFrame !== "undefined") {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (viewRef.current !== editorView) return;
          if (!tryClaimAutofocus() && sawFocusIntent) scheduleAutofocusRetries();
        });
      });
    } else {
      focusRetryTimeouts.push(
        window.setTimeout(() => {
          if (viewRef.current !== editorView) return;
          if (!tryClaimAutofocus() && sawFocusIntent) scheduleAutofocusRetries();
        }, 0),
      );
    }

    // Save cycle. Only flush when there have been local-origin updates since
    // the last flush; ignore remote/AI updates (they were authored elsewhere
    // and saved by that author).
    let dirty = false;
    const onUpdate = (_update: Uint8Array, origin: unknown) => {
      if (origin === "remote" || origin === "ai") return;
      dirty = true;
    };
    doc.on("update", onUpdate);
    const flush = () => {
      if (suppressSaveRef?.current) return;
      if (!treeRef.current.byId.has(componentId)) return;
      if (!dirty) return;
      dirty = false;
      try {
        void Promise.resolve(
          saveYjsState({
            componentId,
            data: Y.encodeStateAsUpdate(doc),
          }),
        ).catch(() => {
          // Block may have been soft-deleted between flush scheduling and
          // the reducer round-trip — safe to ignore.
        });
      } catch (err) {
        if (typeof console !== "undefined") {
          console.warn(
            `[RichTextEditor] save failed for component ${componentId}:`,
            err,
          );
        }
      }
    };
    const interval = window.setInterval(flush, SAVE_INTERVAL_MS);
    const onBeforeUnload = () => flush();
    window.addEventListener("beforeunload", onBeforeUnload);

    return () => {
      for (const id of focusRetryTimeouts) window.clearTimeout(id);
      unregisterBindFocus?.();
      unregisterEditor();
      unregisterText?.();
      unregisterUndo();
      doc.off("update", onUpdate);
      window.clearInterval(interval);
      window.removeEventListener("beforeunload", onBeforeUnload);
      flush();
      editorView.destroy();
      viewRef.current = null;
      setView(null);
      idb.destroy();
      idbRef.current = null;
    };
    // We intentionally rebuild the view if the doc identity changes — that
    // signals a different RichText node, not an update to the same one.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doc, componentId, idbPrefix]);

  const proseClass =
    surfaceMode.kind === "heading"
      ? HEADING_EDITOR_PROSE[surfaceMode.level]
      : textDensity === "listItem"
        ? EDITOR_PROSE_LIST_ITEM
        : EDITOR_PROSE_DEFAULT;

  return (
    <>
      <div ref={hostRef} className={proseClass} />
      <FormattingToolbar view={view} componentId={componentId} linkRequest={linkRequest} blockActions={blockActions} />
    </>
  );
}

function navigateToHref(href: string): void {
  if (href.startsWith("/") || href.startsWith("#")) {
    window.location.assign(href);
    return;
  }
  try {
    const url = new URL(href, window.location.href);
    if (url.origin === window.location.origin) {
      window.location.assign(url.href);
    } else {
      window.open(url.href, "_blank", "noopener,noreferrer");
    }
  } catch {
    window.location.assign(href);
  }
}

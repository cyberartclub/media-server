import type { EditorView } from "prosemirror-view";
import { Selection } from "prosemirror-state";
import * as Y from "yjs";
import { prosemirrorToYDoc } from "y-prosemirror";
import type { SurfaceFocusValue } from "./focus/SurfaceFocusCoordinator";
import { knownSiblingIdsForParent } from "./focus/insertFocusHelpers";
import { resolveNestTarget, getDocumentPrevBlock } from "./navigation/blockNavigation";
import type { SlashMenuItem } from "./SlashMenu";
import { normalizeTextAlign, headingPropsJson } from "./rich-text/richTextFormatting";
import type { BlockId, BlockNode, BlockTree, PulpMutations } from "./types";
import type { PastedBlock } from "./rich-text/pasteToBlocks";
import { yDocToPlainText } from "./rich-text/yjsToHtml";
import {
  PROSEMIRROR_FRAGMENT_KEY,
  richTextSchema,
} from "./rich-text/richTextSchema";

/**
 * Append plain text onto a `RichText` block — live editor when mounted,
 * otherwise rewrite the stored Y.Doc (plain-text merge only).
 * Returns the doc position where the inserted text begins (for caret
 * placement).
 */
export function mergePlainTextIntoRichText(
  prevId: BlockNode["id"],
  text: string,
  tree: BlockTree,
  focus: SurfaceFocusValue,
  saveYjsState: (args: { componentId: BlockNode["id"]; data: Uint8Array }) => void,
): number | null {
  if (!text) return null;

  const prevView = focus.getEditor(prevId);
  if (prevView) {
    const mergePoint = prevView.state.doc.content.size - 1;
    const tr = prevView.state.tr.insertText(text, mergePoint);
    tr.setSelection(Selection.near(tr.doc.resolve(mergePoint)));
    prevView.dispatch(tr);
    prevView.focus();
    return mergePoint;
  }

  const yjs = tree.yjs.get(prevId);
  let existing = "";
  if (yjs?.data && yjs.data.byteLength > 0) {
    const doc = new Y.Doc();
    Y.applyUpdate(doc, yjs.data);
    existing = yDocToPlainText(doc);
  }
  const mergePoint = existing.length;
  saveYjsState({
    componentId: prevId,
    data: Y.encodeStateAsUpdate(plainTextToYDoc(existing + text)),
  });
  return mergePoint;
}

/** Document list block types (distinct from data-bound substrate `List`). */
export const DOCUMENT_LIST_ITEM_TYPES = new Set([
  "BulletListItem",
  "NumberedListItem",
  "ChecklistItem",
]);

export function isDocumentListItemType(componentType: string): boolean {
  return DOCUMENT_LIST_ITEM_TYPES.has(componentType);
}

/**
 * Lift direct children to the block's parent, inserted immediately after
 * `node`, preserving child order. Call before soft-deleting a block that
 * still owns nested rows — the renderer hides any subtree whose ancestor
 * chain includes a deleted node.
 */
export function reparentDirectChildrenBeforeRemoval(
  node: BlockNode,
  tree: BlockTree,
  moveBlock: PulpMutations["moveBlock"],
): void {
  if (node.parentId == null) return;
  const children = tree.byParent.get(node.id);
  if (!children?.length) return;

  let afterSiblingId: BlockId | undefined = node.id;
  for (const child of children) {
    moveBlock({
      componentId: child.id,
      newParentId: node.parentId,
      afterSiblingId,
    });
    afterSiblingId = child.id;
  }
}

/**
 * Exit an empty document list item back to plain `RichText` — BlockNote /
 * Notion semantics for Enter on an empty list row.
 */
export function exitEmptyListItemToRichText(
  node: BlockNode,
  tree: BlockTree,
  mutations: Pick<PulpMutations, "insertBlock" | "deleteBlock" | "moveBlock">,
  focus: SurfaceFocusValue,
): boolean {
  if (node.parentId == null) return false;
  if (!isDocumentListItemType(node.componentType)) return false;

  reparentDirectChildrenBeforeRemoval(node, tree, mutations.moveBlock);

  const parentSiblings = tree.byParent.get(node.parentId) ?? [];
  const myIdx = parentSiblings.findIndex((s) => s.id === node.id);
  const predecessor = myIdx > 0 ? parentSiblings[myIdx - 1]?.id : undefined;

  focus.armForInsert(node.parentId, predecessor, {
    focusAt: "start",
    knownSiblingIds: knownSiblingIdsForParent(tree, node.parentId),
  });
  mutations.insertBlock({
    parentId: node.parentId,
    componentType: "RichText",
    propsJson: "{}",
    afterSiblingId: predecessor,
  });
  mutations.deleteBlock({ componentId: node.id });
  return true;
}

/**
 * Convert a document list item back to a plain `RichText` in place, preserving
 * its content (marks included). Notion / BlockNote un-list on the first
 * Backspace at the start of a list item — before any delete or merge. The new
 * RichText lands in the list item's slot (after the same predecessor).
 */
export function unlistToRichText(
  node: BlockNode,
  tree: BlockTree,
  mutations: Pick<PulpMutations, "insertBlock" | "deleteBlock" | "moveBlock">,
  focus: SurfaceFocusValue,
): boolean {
  if (node.parentId == null) return false;
  if (!isDocumentListItemType(node.componentType)) return false;

  reparentDirectChildrenBeforeRemoval(node, tree, mutations.moveBlock);

  const parentSiblings = tree.byParent.get(node.parentId) ?? [];
  const myIdx = parentSiblings.findIndex((s) => s.id === node.id);
  const predecessor = myIdx > 0 ? parentSiblings[myIdx - 1]?.id : undefined;

  const initialDoc = extractCarryDoc(node, tree, focus);

  focus.armForInsert(node.parentId, predecessor, {
    ...(initialDoc ? { initialDoc } : {}),
    focusAt: "start",
    knownSiblingIds: knownSiblingIdsForParent(tree, node.parentId),
  });
  mutations.insertBlock({
    parentId: node.parentId,
    componentType: "RichText",
    propsJson: "{}",
    afterSiblingId: predecessor,
  });
  mutations.deleteBlock({ componentId: node.id });
  return true;
}

/**
 * Nest this block (BlockNote Tab) — under previous sibling's deepest nest
 * point, or backward in document order for multi-level list indent.
 */
export function nestBlockUnderPreviousSibling(
  node: BlockNode,
  tree: BlockTree,
  mutations: Pick<PulpMutations, "moveBlock">,
  focus: SurfaceFocusValue,
): boolean {
  if (node.parentId == null) return false;

  const target = resolveNestTarget(node, tree);
  if (!target) return false;

  const targetChildren = tree.byParent.get(target.id) ?? [];
  const lastChild = targetChildren[targetChildren.length - 1];
  const afterSiblingId =
    lastChild && lastChild.id !== node.id ? lastChild.id : undefined;

  if (node.parentId === target.id && afterSiblingId == null) return false;

  mutations.moveBlock({
    componentId: node.id,
    newParentId: target.id,
    afterSiblingId,
  });
  focus.requestFocus(node.id, "start");
  return true;
}

/**
 * Unnest this block — move it to the grandparent, immediately after its
 * current parent (BlockNote Shift+Tab / list outdent).
 */
export function unnestBlock(
  node: BlockNode,
  tree: BlockTree,
  mutations: Pick<PulpMutations, "moveBlock">,
  focus: SurfaceFocusValue,
): boolean {
  if (node.parentId == null) return false;

  const parent = tree.byId.get(node.parentId);
  if (!parent || parent.parentId == null || !tree.byId.has(parent.parentId)) return false;

  mutations.moveBlock({
    componentId: node.id,
    newParentId: parent.parentId,
    afterSiblingId: parent.id,
  });
  focus.requestFocus(node.id, "start");
  return true;
}

export function canNestBlock(node: BlockNode, tree: BlockTree): boolean {
  if (node.parentId == null) return false;
  return resolveNestTarget(node, tree) != null;
}

export function canUnnestBlock(node: BlockNode, tree: BlockTree): boolean {
  if (node.parentId == null) return false;
  const parent = tree.byId.get(node.parentId);
  return Boolean(parent?.parentId != null && tree.byId.has(parent.parentId));
}

/**
 * Backspace on an empty block — delete and focus the previous block in
 * document order (parent list item when nested, not unnest-to-root).
 */
export function deleteEmptyBlockAndFocusDocumentPrev(
  node: BlockNode,
  tree: BlockTree,
  focus: SurfaceFocusValue,
  mutations: Pick<PulpMutations, "deleteBlock" | "moveBlock">,
): boolean {
  if (node.parentId == null) return false;

  reparentDirectChildrenBeforeRemoval(node, tree, mutations.moveBlock);

  const docPrev = getDocumentPrevBlock(tree, node.id);
  if (docPrev) {
    focus.requestFocus(docPrev.id, "end");
    mutations.deleteBlock({ componentId: node.id });
    return true;
  }

  const parentSiblings = tree.byParent.get(node.parentId) ?? [];
  if (parentSiblings.length <= 1) return false;

  const myIdx = parentSiblings.findIndex((s) => s.id === node.id);
  const neighbour =
    myIdx > 0 ? parentSiblings[myIdx - 1] : parentSiblings[myIdx + 1];
  if (neighbour) focus.requestFocus(neighbour.id, "end");
  mutations.deleteBlock({ componentId: node.id });
  return true;
}

/**
 * Backspace at doc start with content — merge into the document-order
 * previous Yjs block (includes parent list item when this is a nested row).
 */
export function mergeBlockIntoDocumentPrev(
  node: BlockNode,
  view: EditorView,
  tree: BlockTree,
  focus: SurfaceFocusValue,
  mutations: Pick<PulpMutations, "saveYjsState" | "moveBlock">,
  onRemoveSelf: () => void,
): boolean {
  const prev = getDocumentPrevBlock(tree, node.id);
  if (!prev) return false;

  reparentDirectChildrenBeforeRemoval(node, tree, mutations.moveBlock);

  const prevDef = tree.defs.get(prev.componentType);
  if (!prevDef?.hasYjsState) {
    focus.requestFocus(prev.id, "end");
    onRemoveSelf();
    return true;
  }

  const prevView = focus.getEditor(prev.id);
  if (prevView) {
    const prevDocSize = prevView.state.doc.content.size;
    const mergePoint = prevDocSize - 1;
    const myDocSize = view.state.doc.content.size;
    const sliceToMerge = view.state.doc.slice(1, myDocSize - 1, true);

    const tr = prevView.state.tr.replace(mergePoint, mergePoint, sliceToMerge);
    tr.setSelection(Selection.near(tr.doc.resolve(mergePoint)));
    prevView.dispatch(tr);
    prevView.focus();
    onRemoveSelf();
    return true;
  }

  const text = view.state.doc.textContent;
  if (!text) return false;

  const mergePoint = mergePlainTextIntoRichText(
    prev.id,
    text,
    tree,
    focus,
    mutations.saveYjsState,
  );
  if (mergePoint == null) return false;
  focus.requestFocus(prev.id, "end");
  onRemoveSelf();
  return true;
}

/**
 * Insert parsed paste blocks as new siblings after `node`, in document order.
 *
 * The reducer inserts each new node immediately after `after_sibling_id`, so
 * repeated inserts after the same anchor reverse — we therefore insert (and
 * arm the focus batch) in reverse, yielding `node, b0, b1, …`. Each block's
 * Y.Doc is handed off via `armForInsertBatch`; the last block in document
 * order claims focus (caret at the end of the paste).
 */
export function insertBlocksAfter(
  node: BlockNode,
  blocks: PastedBlock[],
  mutations: Pick<PulpMutations, "insertBlock">,
  focus: SurfaceFocusValue,
  tree: BlockTree,
): boolean {
  if (node.parentId == null || blocks.length === 0) return false;
  const parentId = node.parentId;
  const knownSiblingIds = knownSiblingIdsForParent(tree, parentId);

  const reversed = [...blocks].reverse();
  focus.armForInsertBatch(
    reversed.map((b, i) => ({
      parentId,
      afterSiblingId: node.id,
      initialDoc: b.doc,
      // reversed[0] is the last block in document order → it gets focus.
      shouldFocus: i === 0,
      focusAt: "end" as const,
      knownSiblingIds,
    })),
  );
  for (const b of reversed) {
    mutations.insertBlock({
      parentId,
      componentType: b.componentType,
      propsJson: JSON.stringify(b.props),
      afterSiblingId: node.id,
    });
  }
  return true;
}

/** Delete every block in a block selection (multi-block Backspace/Delete). */
export function deleteBlocks(
  ids: readonly BlockNode["id"][],
  deleteBlock: PulpMutations["deleteBlock"],
): void {
  for (const id of ids) deleteBlock({ componentId: id });
}

/** Clone a block as a new sibling immediately below. Shallow — children are not copied. */
export function duplicateBlock(
  node: BlockNode,
  tree: BlockTree,
  mutations: PulpMutations,
  focus: SurfaceFocusValue,
): void {
  if (node.parentId == null) return;

  const def = tree.defs.get(node.componentType);
  let initialDoc: Y.Doc | undefined;

  if (def?.hasYjsState) {
    const view = focus.getEditor(node.id);
    if (view) {
      initialDoc = prosemirrorToYDoc(view.state.doc, PROSEMIRROR_FRAGMENT_KEY);
    } else {
      const yjs = tree.yjs.get(node.id);
      if (yjs?.data && yjs.data.byteLength > 0) {
        initialDoc = new Y.Doc();
        Y.applyUpdate(initialDoc, yjs.data);
      }
    }
  }

  focus.armForInsert(node.parentId, node.id, {
    ...(initialDoc ? { initialDoc } : {}),
    focusAt: "start",
    knownSiblingIds: knownSiblingIdsForParent(tree, node.parentId),
  });
  mutations.insertBlock({
    parentId: node.parentId,
    componentType: node.componentType,
    propsJson: node.props,
    afterSiblingId: node.id,
  });
}

/**
 * Replace this block with another component type (Notion-style "Turn into…").
 * Content is carried over when the conversion is straightforward (text ↔ heading).
 */
export function turnIntoBlock(
  node: BlockNode,
  tree: BlockTree,
  item: SlashMenuItem,
  mutations: PulpMutations,
  focus: SurfaceFocusValue,
): void {
  if (node.parentId == null) return;

  if (
    node.componentType === "Heading" &&
    item.componentType === "Heading" &&
    typeof item.defaultProps.level === "number"
  ) {
    const current = safeParseProps(node.props);
    mutations.updateBlockProps({
      componentId: node.id,
      propsJson: headingPropsJson(item.defaultProps.level, {
        textAlign: normalizeTextAlign(current.textAlign),
        collapsed: current.collapsed === true,
        section: current.section === true,
      }),
    });
    return;
  }

  if (
    node.componentType === item.componentType &&
    item.componentType !== "Heading"
  ) {
    return;
  }

  const props = buildTurnIntoProps(item, node);
  const targetDef = tree.defs.get(item.componentType);
  // Carry the full Y.Doc (marks intact) rather than plain text — Notion /
  // BlockNote preserve inline formatting across a type change. Only when the
  // target stores Yjs state; otherwise the content has nowhere to land.
  const initialDoc = targetDef?.hasYjsState
    ? extractCarryDoc(node, tree, focus)
    : undefined;

  reparentDirectChildrenBeforeRemoval(node, tree, mutations.moveBlock);

  const parentSiblings = tree.byParent.get(node.parentId) ?? [];
  const myIdx = parentSiblings.findIndex((s) => s.id === node.id);
  const predecessor = myIdx > 0 ? parentSiblings[myIdx - 1]?.id : undefined;

  focus.armForInsert(node.parentId, predecessor, {
    ...(initialDoc ? { initialDoc } : {}),
    focusAt: "start",
    knownSiblingIds: knownSiblingIdsForParent(tree, node.parentId),
  });
  mutations.insertBlock({
    parentId: node.parentId,
    componentType: item.componentType,
    propsJson: JSON.stringify(props),
    afterSiblingId: predecessor,
  });

  mutations.deleteBlock({ componentId: node.id });
}

/**
 * Build a Y.Doc carrying this block's rich content (marks included) for the
 * turn-into target. Live view → clone the editor doc; otherwise rehydrate the
 * stored Yjs blob. Returns undefined for empty / non-text blocks so an empty
 * conversion (e.g. a markdown shortcut on a blank line) doesn't hand off a
 * doc. Mirrors the doc-clone in `duplicateBlock`.
 */
function extractCarryDoc(
  node: BlockNode,
  tree: BlockTree,
  focus: SurfaceFocusValue,
): Y.Doc | undefined {
  const def = tree.defs.get(node.componentType);
  if (!def?.hasYjsState) return undefined;

  const view = focus.getEditor(node.id);
  if (view) {
    if (view.state.doc.textContent.length === 0) return undefined;
    return prosemirrorToYDoc(view.state.doc, PROSEMIRROR_FRAGMENT_KEY);
  }

  const yjs = tree.yjs.get(node.id);
  if (yjs?.data && yjs.data.byteLength > 0) {
    const doc = new Y.Doc();
    Y.applyUpdate(doc, yjs.data);
    if (yDocToPlainText(doc).length === 0) {
      doc.destroy();
      return undefined;
    }
    return doc;
  }
  return undefined;
}

function buildTurnIntoProps(
  item: SlashMenuItem,
  node: BlockNode,
): Record<string, unknown> {
  if (item.componentType === "Heading") {
    const current =
      node.componentType === "Heading" ? safeParseProps(node.props) : {};
    const align = normalizeTextAlign(current.textAlign);
    return {
      level: item.defaultProps.level ?? 1,
      ...(align !== "left" ? { textAlign: align } : {}),
    };
  }
  if (item.componentType === "RichText") {
    return { ...item.defaultProps };
  }
  if (isDocumentListItemType(item.componentType)) {
    return { ...item.defaultProps };
  }
  if (node.componentType === item.componentType) {
    return safeParseProps(node.props);
  }
  return { ...item.defaultProps };
}

function plainTextToYDoc(text: string): Y.Doc {
  const para = richTextSchema.node(
    "paragraph",
    null,
    text ? richTextSchema.text(text) : undefined,
  );
  const pmDoc = richTextSchema.node("doc", null, [para]);
  return prosemirrorToYDoc(pmDoc, PROSEMIRROR_FRAGMENT_KEY);
}

function safeParseProps(s: string): Record<string, unknown> {
  try {
    return JSON.parse(s) as Record<string, unknown>;
  } catch {
    return {};
  }
}

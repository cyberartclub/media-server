/**
 * Public entry for the platform-agnostic Pear MCP core.
 *
 * Imported by:
 *   - The pear worker's stdio + HTTP MCP hosts (`worker/src/mcp/`).
 *   - The Pear-Cloud Cloudflare gateway (`workers/api`) at
 *     `https://{slug}.api.pear.pro/mcp`.
 *
 * Anything not re-exported here is considered internal and may change.
 */

export { createPearMcpServer, SERVER_INFO } from "./server";
export { buildToolRegistry } from "./tools";
export { resolveAiUser } from "./identity";
export {
  McpAuthError,
  type McpContext,
  type McpToolEntry,
  type WorkspaceFile,
  type WorkspaceFileReader,
} from "./types";
// The page-body renderer, shared with the worker's page-context reader so
// chat and MCP agents see identical document text.
export { renderDocTree, collectDocYjsIds, type DocNode } from "./doc-render";
// Shared "what counts as text" rules for hosts implementing WorkspaceFileReader.
export {
  capText,
  decodeUtf8,
  extractorFor,
  isTextLikeType,
  looksLikeUtf8Text,
  type TextExtractor,
} from "./file-text";
export { HttpStdbTransport, type StdbTransport } from "../api-endpoint";
// Re-exported so external consumers (the CF gateway) resolve the SDK from
// THIS package's node_modules — one bundled copy, no version skew with the
// Server instances createPearMcpServer builds.
export { createMcpHandler, type AuthInfo } from "@modelcontextprotocol/server";

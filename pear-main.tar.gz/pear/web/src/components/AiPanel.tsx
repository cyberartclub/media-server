"use client";

import { memo, useState, useRef, useEffect, useLayoutEffect, useCallback, useMemo } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import { useSpacetimeDB } from "spacetimedb/react";
import Markdown, { type Components } from "react-markdown";
import { useVirtualizer } from "@tanstack/react-virtual";
import remarkGfm from "remark-gfm";
import { useOrchaJobs, type OrchaJobRow } from "@/src/hooks/useOrcha";
import { OrchaJobCard } from "@/src/components/OrchaJobCard";
import type {
  AutomationEventQueue,
  BridgeApproval,
  BridgeCommand,
  MessageFeedback,
} from "@/src/module_bindings/types";
import {
  useConversations,
  useConversationMessages,
  useConversationParticipants,
  useCreateConversation,
  useFindOrCreateAiDm,
  useFindOrCreateDm,
  useDmConversation,
  useAddConversationParticipant,
  isVisibleConversationMessage,
  useSendMessage,
  useSendUserMessage,
  useAttachmentsForConversation,
  useCloseConversation,
  useSetConversationModel,
  useParticipantsForConversation,
  identitiesEqual,
  type ConversationRow,
  type ConversationMessageRow,
  type ConversationAttachmentRow,
} from "@/src/hooks/useConversations";
import {
  providerModels,
  PRESET_BY_PROVIDER_NAME,
} from "@/src/lib/aiUserApi";
import {
  PAGE_DRAG_MIME,
  newLocalId,
  isImageFile,
  uploadChatFile,
  chatImageSrc,
  chatFileHref,
  toAttachmentSpecs,
  extractTextFromBlockJson,
  type PendingAttachment,
  type PageDragPayload,
} from "@/src/lib/chatAttachments";
import { usePearWorkspaceSlug } from "@/src/lib/blobUpload";
import { formatBytes } from "@/src/lib/formatBytes";
import { optionStringFromRow } from "@/src/lib/spacetime";
import {
  findActiveMentionQuery,
  insertMention,
} from "@/src/lib/mentionQuery";
import { useUsers } from "@/src/hooks/useUser";
import {
  useAiUserProfiles,
  useAiUserInConversation,
  type AiUserProfileRow,
} from "@/src/hooks/useAiUsers";
import { ContextBar } from "@/src/components/ContextBar";
import { HumanInputRequests } from "@/src/components/HumanInputRequests";
import { BridgeApprovalCard } from "@/src/components/BridgeApprovalCard";
import { StaticComponentTree } from "@/src/components/component-renderers/StaticComponentTree";
import { useTable, useReducer } from "spacetimedb/react";
import { tables, reducers } from "@/src/module_bindings";
import type { Identity } from "spacetimedb";

/**
 * A delegated Orcha job rendered inline in the conversation thread as a
 * subagent-style card — the full expandable task breakdown (`JobCard`) framed
 * so it reads as "this message spawned a background subagent."
 */
function InlineJobCard({ job }: { job: OrchaJobRow }) {
  return (
    <div className="mt-2 pl-2.5 border-l-2 border-violet-300/60 dark:border-violet-600/40">
      <div className="flex items-center gap-1.5 mb-1.5">
        <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-500">
          <rect x="3" y="11" width="18" height="10" rx="2" /><circle cx="12" cy="5" r="2" /><path d="M12 7v4M8 16h.01M16 16h.01" />
        </svg>
        <span className="text-[10px] font-medium uppercase tracking-wide text-violet-500/90">
          Delegated subagent
        </span>
      </div>
      <OrchaJobCard job={job} />
    </div>
  );
}

// ── Thinking block (collapsible) ──────────────────────────────────────────────

// Shared markdown config for AI message content. `remark-gfm` enables GitHub
// tables, task lists, strikethrough, and autolinks (react-markdown ships these
// OFF by default — without it a GFM table renders as one line of raw pipes).
// Wide tables scroll within the narrow chat panel instead of overflowing it.
const MD_REMARK_PLUGINS = [remarkGfm];
/** Stable empty array so attachment-less messages don't churn props. */
const NO_MESSAGE_ATTACHMENTS: ConversationAttachmentRow[] = [];
/** Stable empty array so conversations without messages don't churn props. */
const NO_CONVERSATION_MESSAGES: ConversationMessageRow[] = [];
/** Stable empty array so messages without bridge commands don't churn props. */
const NO_BRIDGE_COMMANDS: BridgeCommand[] = [];
const MD_COMPONENTS: Components = {
  table: ({ node: _node, ...props }) => (
    <div className="overflow-x-auto">
      <table {...props} />
    </div>
  ),
};

/**
 * react-markdown parses synchronously in render with no caching, so it must
 * only re-render when its source text changes. During streaming the worker
 * flushes ~every 300ms; this memo caps each flush's parse cost at the one
 * message (segment) that grew instead of the whole transcript.
 */
const MemoMarkdown = memo(function MemoMarkdown({ text }: { text: string }) {
  return (
    <Markdown remarkPlugins={MD_REMARK_PLUGINS} components={MD_COMPONENTS}>
      {text}
    </Markdown>
  );
});

function ThinkingBlock({ thinking, isStreaming }: { thinking: string; isStreaming: boolean }) {
  const [expanded, setExpanded] = useState(isStreaming);

  // Expand live while the model is thinking, then auto-collapse once the answer
  // lands so completed messages stay tidy. Manual toggles persist until the
  // streaming state next flips.
  useEffect(() => {
    setExpanded(isStreaming);
  }, [isStreaming]);

  return (
    <div className="mt-1.5 mb-1.5">
      <button
        onClick={() => setExpanded((e) => !e)}
        className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
      >
        {isStreaming && (
          <span className="w-1.5 h-1.5 rounded-full bg-violet-500 animate-pulse shrink-0" />
        )}
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="10"
          height="10"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={`transition-transform ${expanded ? "rotate-90" : ""}`}
        >
          <polyline points="9 18 15 12 9 6" />
        </svg>
        <span>Thinking{isStreaming ? "…" : ""}</span>
      </button>
      {expanded && (
        <div className="mt-1 pl-3 border-l-2 border-violet-300/40 dark:border-violet-600/30">
          <p className="text-xs text-neutral-400 dark:text-neutral-500 whitespace-pre-wrap font-mono leading-relaxed max-h-48 overflow-y-auto">
            {thinking}
            {isStreaming && <span className="animate-pulse">|</span>}
          </p>
        </div>
      )}
    </div>
  );
}

// ── Tool call display ─────────────────────────────────────────────────────────

/** Concrete entities a mutating tool touched (mirror of worker AffectedEntities, #32). */
interface AffectedEntities {
  pageId?: number;
  createdNodeIds?: number[];
  propertyDefinitionId?: number;
  jobId?: number;
}

/** Unified persisted tool-call shape; `result` kept for legacy rows. */
interface ToolCallInfo {
  /** tool_use id — used to resolve a timeline `{t:"tool",id}` block to its call. */
  id?: string;
  name: string;
  status: "executing" | "done" | "error";
  output?: string;
  affected?: AffectedEntities;
  /** JSON-stringified tool input (e.g. `{device_id, command}` for tool_bash). */
  input?: string;
  /** Legacy field (pre-unified shape). */
  result?: string;
}

/** Live status labels for a matched `bridge_command` row (BridgeCommandStatus). */
const BRIDGE_STATUS_LABEL: Record<string, string> = {
  Pending: "queued",
  AwaitingConfirmation: "needs approval",
  Running: "running",
  Completed: "done",
  Failed: "failed",
  Rejected: "rejected",
  TimedOut: "timed out",
};

/** Pull the shell command out of a tool_bash call's stored `input`. */
function bashCommandOf(tc: ToolCallInfo): string | null {
  if (!tc.input) return null;
  try {
    const o = JSON.parse(tc.input) as { command?: unknown };
    return typeof o.command === "string" ? o.command : null;
  } catch {
    return null;
  }
}

/** Short human summary of what a tool call touched, for the chat receipt (#32). */
function affectedSummary(a: AffectedEntities | undefined): string | null {
  if (!a) return null;
  const bits: string[] = [];
  if (a.pageId !== undefined) bits.push(`page ${a.pageId}`);
  if (a.createdNodeIds?.length) bits.push(`${a.createdNodeIds.length} block${a.createdNodeIds.length === 1 ? "" : "s"}`);
  if (a.propertyDefinitionId !== undefined) bits.push(`property ${a.propertyDefinitionId}`);
  if (a.jobId !== undefined) bits.push(`job ${a.jobId}`);
  return bits.length > 0 ? bits.join(", ") : null;
}

const TOOL_ICONS: Record<string, string> = {
  web_search: "search",
  fetch_url: "globe",
};

/** A single tool-call card. Extracted so both the batched `ToolCallsDisplay`
 * and the interleaved `TimelineDisplay` can render an identical card. */
function ToolCallItem({
  tc,
  conversationId,
  bridgeCommands,
}: {
  tc: ToolCallInfo;
  conversationId: bigint;
  /** bridge_command rows already scoped to this conversation (hoisted to the thread). */
  bridgeCommands: BridgeCommand[];
}) {
  const router = useRouter();
  const confirmCommand = useReducer(reducers.confirmBridgeCommand);
  const denyCommand = useReducer(reducers.denyBridgeCommand);
  const [bridgeBusy, setBridgeBusy] = useState<string | null>(null);

  // Most-recent bridge_command matching a command string — links a tool_bash
  // call to its live row (status + approval).
  const matchBridge = (command: string) =>
    bridgeCommands
      .filter((c) => c.command === command)
      .reduce<BridgeCommand | undefined>(
        (best, c) => (best && best.id > c.id ? best : c),
        undefined,
      );
  const decideBridge = async (commandId: bigint, action: "allow" | "always" | "deny") => {
    setBridgeBusy(`${commandId}:${action}`);
    try {
      if (action === "deny") await denyCommand({ commandId });
      else await confirmCommand({ commandId, remember: action === "always" });
    } finally {
      setBridgeBusy(null);
    }
  };

  // tool_bash: show the command + live bridge status + inline approval.
  if (tc.name === "tool_bash") {
    const command = bashCommandOf(tc);
    const match = command ? matchBridge(command) : undefined;
    const statusTag = match?.status.tag;
    const awaiting = statusTag === "AwaitingConfirmation";
    const live = statusTag ? BRIDGE_STATUS_LABEL[statusTag] ?? statusTag : null;
    // Trust the bridge row's terminal status over a stale `executing`
    // tool-call (the worker can lag delivering the result). Completed/
    // failed/rejected/timed-out ⇒ not running, even if tc says executing.
    const terminal =
      statusTag === "Completed" ||
      statusTag === "Failed" ||
      statusTag === "Rejected" ||
      statusTag === "TimedOut";
    const failed =
      statusTag === "Failed" ||
      statusTag === "Rejected" ||
      statusTag === "TimedOut" ||
      tc.status === "error";
    const running = tc.status === "executing" && !awaiting && !terminal;
    const btn = (action: "allow" | "always" | "deny", label: string, cls: string) => (
      <button
        type="button"
        disabled={bridgeBusy !== null}
        onClick={() => match && void decideBridge(match.id, action)}
        className={`rounded px-2 py-0.5 text-[11px] font-medium disabled:opacity-50 ${cls}`}
      >
        {bridgeBusy === `${match?.id}:${action}` ? "…" : label}
      </button>
    );
    return (
      <div className="rounded-md border border-neutral-200 bg-neutral-50 px-2 py-1.5 dark:border-neutral-800 dark:bg-neutral-900/40">
        <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
          {running ? (
            <span className="w-3 h-3 rounded-full border-2 border-violet-400 border-t-transparent animate-spin shrink-0" />
          ) : awaiting ? (
            <span className="text-amber-500 shrink-0">⏸</span>
          ) : failed ? (
            <span className="text-red-500 shrink-0">✕</span>
          ) : (
            <span className="text-green-500 shrink-0">✓</span>
          )}
          <span className="font-medium">bridge shell</span>
          {live && (
            <span
              className={`rounded px-1 text-[10px] ${
                awaiting
                  ? "bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300"
                  : "bg-neutral-200 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400"
              }`}
            >
              {live}
            </span>
          )}
        </div>
        {command && (
          <code className="mt-1 block break-all font-mono text-[11px] text-neutral-700 dark:text-neutral-300">
            $ {command}
          </code>
        )}
        {awaiting && match && (
          <div className="mt-1.5 flex gap-1.5">
            {btn("allow", "Allow once", "bg-emerald-600 text-white hover:bg-emerald-700")}
            {btn(
              "always",
              "Always allow",
              "bg-emerald-100 text-emerald-800 hover:bg-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300",
            )}
            {btn(
              "deny",
              "Deny",
              "bg-neutral-100 text-neutral-600 hover:bg-neutral-200 dark:bg-neutral-800 dark:text-neutral-400",
            )}
          </div>
        )}
      </div>
    );
  }

  const summary = affectedSummary(tc.affected) ?? (tc.status === "done" ? tc.result : undefined);
  const node = tc.affected?.createdNodeIds?.[0];
  // Jump-to-change deep link: open the affected page (and the changed
  // block, if any), keeping this conversation open (#32).
  const href = tc.affected?.pageId !== undefined
    ? `/workspace/${tc.affected.pageId}?conversation=${conversationId}${node !== undefined ? `&node=${node}` : ""}`
    : null;
  return (
    <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
      {tc.status === "executing" ? (
        <span className="w-3 h-3 rounded-full border-2 border-violet-400 border-t-transparent animate-spin shrink-0" />
      ) : tc.status === "done" ? (
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 shrink-0">
          <polyline points="20 6 9 17 4 12" />
        </svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-red-500 shrink-0">
          <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      )}
      <span className="font-medium">{tc.name.replace(/_/g, " ")}</span>
      {href ? (
        <button
          type="button"
          onClick={() => router.push(href)}
          className="text-violet-500 hover:text-violet-600 hover:underline truncate max-w-[160px]"
          title={`Jump to change — ${summary ?? "open page"}`}
        >
          → {summary ?? "open page"}
        </button>
      ) : (
        summary && (
          <span className="text-neutral-400 truncate max-w-[160px]" title={summary}>
            — {summary}
          </span>
        )
      )}
    </div>
  );
}

/** Batched tool-call list (used when a message has no render timeline). */
function ToolCallsDisplay({
  toolCallsJson,
  conversationId,
  bridgeCommands,
}: {
  toolCallsJson: string;
  conversationId: bigint;
  bridgeCommands: BridgeCommand[];
}) {
  let calls: ToolCallInfo[] = [];
  try {
    calls = JSON.parse(toolCallsJson);
  } catch {
    return null;
  }
  if (calls.length === 0) return null;
  return (
    <div className="mt-1.5 mb-1.5 space-y-1">
      {calls.map((tc, i) => (
        <ToolCallItem key={i} tc={tc} conversationId={conversationId} bridgeCommands={bridgeCommands} />
      ))}
    </div>
  );
}

type TimelineBlock = { t: "text"; text: string } | { t: "tool"; id: string };

/** Interleaved render of a turn: text segments and tool cards in the order they
 * happened (the worker's `timeline_json`). Tool blocks are resolved to their
 * full call (name/status/output) by id from `toolCallsJson`. */
function TimelineDisplay({
  blocks,
  toolCallsJson,
  conversationId,
  bridgeCommands,
  streaming,
}: {
  blocks: TimelineBlock[];
  toolCallsJson: string | undefined;
  conversationId: bigint;
  bridgeCommands: BridgeCommand[];
  streaming: boolean;
}) {
  const byId = useMemo(() => {
    let calls: ToolCallInfo[] = [];
    try {
      calls = toolCallsJson ? JSON.parse(toolCallsJson) : [];
    } catch {
      calls = [];
    }
    const map = new Map<string, ToolCallInfo>();
    for (const c of calls) if (c.id) map.set(c.id, c);
    return map;
  }, [toolCallsJson]);

  return (
    <div className="mt-1 space-y-1.5">
      {blocks.map((b, i) => {
        if (b.t === "text") {
          return b.text ? (
            <div
              key={i}
              className="ai-message-md text-sm leading-relaxed prose prose-sm prose-neutral dark:prose-invert max-w-none"
            >
              <MemoMarkdown text={b.text} />
            </div>
          ) : null;
        }
        const tc = byId.get(b.id);
        return tc ? (
          <ToolCallItem key={i} tc={tc} conversationId={conversationId} bridgeCommands={bridgeCommands} />
        ) : null;
      })}
      {streaming && <span className="animate-pulse">|</span>}
    </div>
  );
}

// ── AI message content with status-aware rendering ────────────────────────────

// Memoized on the message row object: the SDK's table cache only replaces a
// row object when that row changes, so during streaming only the growing
// message re-renders — not the whole transcript.
const AiMessageContent = memo(function AiMessageContent({
  msg,
  aiName,
  bridgeCommands,
  automationEventsByKey,
  feedback,
}: {
  msg: ConversationMessageRow;
  aiName: string;
  /** bridge_command rows scoped to this message's tool_bash calls (hoisted to the thread). */
  bridgeCommands: BridgeCommand[];
  /** automation_event_queue rows indexed by idempotency key (hoisted to the thread). */
  automationEventsByKey: ReadonlyMap<string, AutomationEventQueue>;
  /** Current user's feedback row for this message, if any. */
  feedback: MessageFeedback | undefined;
}) {
  const status = msg.status?.tag ?? "Complete";
  const thinking = msg.thinking;
  const toolCallsJson = msg.toolCallsJson;

  // Render timeline (text segments interleaved with tool cards in order). When
  // present it supersedes the separate tool-list + content blocks; falls back to
  // the legacy layout for messages without one (pre-timeline rows, or a parse
  // failure).
  const timelineBlocks = useMemo<TimelineBlock[] | null>(() => {
    if (!msg.timelineJson) return null;
    try {
      const parsed = JSON.parse(msg.timelineJson);
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : null;
    } catch {
      return null;
    }
  }, [msg.timelineJson]);

  return (
    <>
      {/* Thinking block */}
      {thinking && (
        <ThinkingBlock
          thinking={thinking}
          isStreaming={status === "Thinking"}
        />
      )}

      {timelineBlocks ? (
        <TimelineDisplay
          blocks={timelineBlocks}
          toolCallsJson={toolCallsJson}
          conversationId={msg.conversationId}
          bridgeCommands={bridgeCommands}
          streaming={status === "Streaming"}
        />
      ) : (
        <>
          {/* Tool calls */}
          {toolCallsJson && (
            <ToolCallsDisplay
              toolCallsJson={toolCallsJson}
              conversationId={msg.conversationId}
              bridgeCommands={bridgeCommands}
            />
          )}

          {/* Message content */}
          {msg.content && (
            <div className="ai-message-md text-sm leading-relaxed prose prose-sm prose-neutral dark:prose-invert max-w-none">
              <MemoMarkdown text={msg.content} />
              {status === "Streaming" && <span className="animate-pulse">|</span>}
            </div>
          )}
        </>
      )}

      {/* Inline generative UI. Its component tree remains structurally
          read-only; generated controls may invoke server-authorized Manual
          automations through the narrow interaction context. */}
      {msg.componentTreeJson && (
        <StaticComponentTree
          json={msg.componentTreeJson}
          messageId={msg.id}
          automationEventsByKey={automationEventsByKey}
        />
      )}

      {/* Thinking indicator (no thinking text yet) */}
      {status === "Thinking" && !thinking && !msg.content && !timelineBlocks && (
        <div className="flex items-center gap-1.5 py-1">
          <span className="w-1.5 h-1.5 rounded-full bg-violet-400 dark:bg-violet-500 animate-bounce [animation-delay:0ms]" />
          <span className="w-1.5 h-1.5 rounded-full bg-violet-400 dark:bg-violet-500 animate-bounce [animation-delay:150ms]" />
          <span className="w-1.5 h-1.5 rounded-full bg-violet-400 dark:bg-violet-500 animate-bounce [animation-delay:300ms]" />
        </div>
      )}

      {/* Error state */}
      {status === "Error" && !msg.content && (
        <p className="text-xs text-red-500 italic">Failed to generate response</p>
      )}

      {/* Human review: thumbs up/down feedback on the finished turn. Replaces the
          old self-graded "intent check" banner with a durable, RLS-scoped signal. */}
      {status === "Complete" && (msg.content || toolCallsJson) && (
        <MessageFeedbackControl messageId={msg.id} mine={feedback} />
      )}
    </>
  );
});

// ── Message feedback (thumbs up/down) ─────────────────────────────────────────

/**
 * Durable human-review control on an assistant message. `message_feedback` is
 * RLS-scoped to the rater, so `useTable` only ever yields this user's own rows;
 * we find this message's row to reflect/toggle the current rating. Re-clicking
 * the active rating clears it; clicking the other flips it in place.
 */
function MessageFeedbackControl({
  messageId,
  mine,
}: {
  messageId: bigint;
  /** This user's feedback row for this message (table is RLS-scoped to the rater). */
  mine: MessageFeedback | undefined;
}) {
  const setFeedback = useReducer(reducers.setMessageFeedback);
  const clearFeedback = useReducer(reducers.clearMessageFeedback);
  const [busy, setBusy] = useState(false);

  const current = mine?.rating?.tag as "Up" | "Down" | undefined;

  const apply = async (rating: "Up" | "Down") => {
    if (busy) return;
    setBusy(true);
    try {
      if (current === rating) await clearFeedback({ messageId });
      else await setFeedback({ messageId, rating: { tag: rating }, note: undefined });
    } finally {
      setBusy(false);
    }
  };

  const btn = (rating: "Up" | "Down") => {
    const active = current === rating;
    const tone = rating === "Up" ? "text-emerald-500" : "text-rose-500";
    return (
      <button
        type="button"
        onClick={() => apply(rating)}
        disabled={busy}
        aria-pressed={active}
        aria-label={rating === "Up" ? "Good response" : "Bad response"}
        title={rating === "Up" ? "Good response" : "Needs work"}
        className={`p-1 rounded transition-colors disabled:opacity-50 ${
          active
            ? tone
            : "text-neutral-400 hover:text-neutral-600 dark:text-neutral-500 dark:hover:text-neutral-300"
        }`}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="13"
          height="13"
          viewBox="0 0 24 24"
          fill={active ? "currentColor" : "none"}
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className={rating === "Down" ? "rotate-180" : undefined}
        >
          <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" />
        </svg>
      </button>
    );
  };

  return (
    <div className="mt-1.5 flex items-center gap-0.5 opacity-60 hover:opacity-100 transition-opacity">
      {btn("Up")}
      {btn("Down")}
    </div>
  );
}

// ── Linked conversation card ─────────────────────────────────────────────────

function LinkedConversationCard({ linkedConversationId }: { linkedConversationId: bigint }) {
  const router = useRouter();
  const { conversations } = useConversations();
  const conv = conversations.find((c) => c.id === linkedConversationId);
  const aiUser = useAiUserInConversation(linkedConversationId);
  if (!conv) return null;
  return (
    <button
      onClick={() => router.push(`/workspace/${conv.pageId}?conversation=${conv.id}`)}
      className="mt-1.5 flex items-center gap-2 w-full text-left px-2.5 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800/50 hover:bg-neutral-100 dark:hover:bg-neutral-700/60 transition-colors"
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400 shrink-0">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
      <span className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
        Thread: {aiUser?.displayName ?? "Context thread"} → Open
      </span>
    </button>
  );
}

// ── Attachments ──────────────────────────────────────────────────────────────

function PaperclipIcon({ className = "", size = 12 }: { className?: string; size?: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48" />
    </svg>
  );
}

/** Chips + thumbnails for attachments queued in the composer (removable). */
function ComposerAttachments({
  pending,
  onRemove,
}: {
  pending: PendingAttachment[];
  onRemove: (id: string) => void;
}) {
  if (pending.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1.5 mb-2">
      {pending.map((att) => (
        <div
          key={att.id}
          className="group relative flex items-center gap-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-900 px-1.5 py-1"
        >
          {att.kind === "image" ? (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={att.previewUrl}
                alt={att.fileName}
                className={`w-8 h-8 rounded object-cover ${att.status === "uploading" ? "opacity-50" : ""}`}
              />
              <span className="text-[11px] text-neutral-500 max-w-[90px] truncate">
                {att.status === "uploading"
                  ? "Uploading…"
                  : att.status === "error"
                    ? "Upload failed"
                    : att.fileName}
              </span>
            </>
          ) : att.kind === "file" ? (
            <>
              <PaperclipIcon className={`text-neutral-400 shrink-0 ${att.status === "uploading" ? "opacity-50" : ""}`} />
              <span
                className={`text-[11px] max-w-[140px] truncate ${att.status === "error" ? "text-red-500" : "text-neutral-600 dark:text-neutral-300"}`}
                title={`${att.fileName}${att.sizeBytes ? ` · ${formatBytes(att.sizeBytes)}` : ""}`}
              >
                {att.status === "uploading"
                  ? `Uploading ${att.fileName}…`
                  : att.status === "error"
                    ? `Upload failed: ${att.fileName}`
                    : att.fileName}
              </span>
            </>
          ) : (
            <>
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400 shrink-0">
                {att.kind === "page" ? (
                  <>
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                  </>
                ) : (
                  <>
                    <line x1="21" y1="6" x2="3" y2="6" />
                    <line x1="21" y1="12" x2="9" y2="12" />
                    <line x1="21" y1="18" x2="7" y2="18" />
                  </>
                )}
              </svg>
              <span className="text-[11px] text-neutral-600 dark:text-neutral-300 max-w-[120px] truncate">
                {att.kind === "page" ? att.title : (att.title ?? "Selection")}
              </span>
            </>
          )}
          <button
            onClick={() => onRemove(att.id)}
            title="Remove"
            className="ml-0.5 p-0.5 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      ))}
    </div>
  );
}

/** Attachments on a sent message: image thumbnails (workspace blob route) + context chips. */
function MessageAttachments({ attachments }: { attachments: ConversationAttachmentRow[] }) {
  const slug = usePearWorkspaceSlug();
  if (attachments.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1.5 mb-1.5">
      {attachments.map((att) => {
        if (att.kind.tag === "Image" && att.objectKey) {
          return (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              key={String(att.id)}
              src={chatImageSrc(slug, att.objectKey)}
              alt={att.fileName ?? "attachment"}
              className="max-w-[160px] max-h-[120px] rounded-lg object-cover border border-black/10 dark:border-white/10"
            />
          );
        }
        if (att.kind.tag === "File") {
          const name = att.fileName ?? "file";
          const href = att.objectKey ? chatFileHref(slug, att.objectKey, name) : "";
          const chip = (
            <>
              <PaperclipIcon className="shrink-0" />
              <span className="truncate max-w-[180px]">{name}</span>
            </>
          );
          return href ? (
            <a
              key={String(att.id)}
              href={href}
              className="inline-flex items-center gap-1 rounded-md bg-black/10 dark:bg-white/10 px-1.5 py-0.5 text-[11px] opacity-80 hover:opacity-100 hover:underline"
              title={`Download ${name}${att.mimeType ? ` (${att.mimeType})` : ""}`}
            >
              {chip}
            </a>
          ) : (
            <span
              key={String(att.id)}
              className="inline-flex items-center gap-1 rounded-md bg-black/10 dark:bg-white/10 px-1.5 py-0.5 text-[11px] opacity-80"
            >
              {chip}
            </span>
          );
        }
        return (
          <span
            key={String(att.id)}
            className="inline-flex items-center gap-1 rounded-md bg-black/10 dark:bg-white/10 px-1.5 py-0.5 text-[11px] opacity-80"
            title={att.contentSnapshot?.slice(0, 500)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
            </svg>
            {att.fileName ?? (att.kind.tag === "Page" ? "Page" : "Selection")}
          </span>
        );
      })}
    </div>
  );
}

// ── Conversation thread ──────────────────────────────────────────────────────

/**
 * Thread-header model switcher. Shows the effective model (per-conversation
 * override, else the AI user's configured default) and lets the operator pin a
 * different model for this thread or revert to the default. Only the model
 * changes — the AI user's provider and API key still apply, so picks are limited
 * to the family that key unlocks.
 */
function ConversationModelSwitcher({
  conversation,
  aiUser,
}: {
  conversation: ConversationRow;
  aiUser: AiUserProfileRow;
}) {
  const setConversationModel = useSetConversationModel();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const defaultModel = aiUser.modelName;
  const override = conversation.modelOverride ?? undefined;
  const effective = override ?? defaultModel;
  const catalog = providerModels(PRESET_BY_PROVIDER_NAME[aiUser.providerName] ?? "Ollama");

  const apply = async (model: string | undefined) => {
    setOpen(false);
    if (model === override) return;
    setBusy(true);
    try {
      await setConversationModel({ conversationId: conversation.id, model });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        disabled={busy}
        title="Change the model for this conversation"
        className="flex items-center gap-1 max-w-full text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 disabled:opacity-50 transition-colors"
      >
        <span className="truncate">
          {aiUser.providerName} · {effective}
        </span>
        {override && (
          <span className="shrink-0 rounded bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 px-1 text-[10px] font-medium">
            override
          </span>
        )}
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0 opacity-70">
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-full mt-1 z-20 min-w-[13rem] rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 shadow-lg py-1">
            <MenuModelItem
              label="Default"
              hint={defaultModel}
              active={!override}
              onSelect={() => void apply(undefined)}
            />
            {catalog.length > 0 && (
              <div className="my-1 border-t border-neutral-100 dark:border-neutral-800" />
            )}
            {catalog.map((m) => (
              <MenuModelItem
                key={m.id}
                label={m.label}
                hint={m.tier}
                active={!!override && effective === m.id}
                onSelect={() => void apply(m.id)}
              />
            ))}
            {override && !catalog.some((m) => m.id === override) && (
              <MenuModelItem label={override} hint="custom" active onSelect={() => setOpen(false)} />
            )}
          </div>
        </>
      )}
    </div>
  );
}

function MenuModelItem({
  label,
  hint,
  active,
  onSelect,
}: {
  label: string;
  hint?: string;
  active: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onSelect}
      className="w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
    >
      <span className={`w-3 shrink-0 ${active ? "text-violet-600 dark:text-violet-400" : "opacity-0"}`}>✓</span>
      <span className="flex-1 truncate font-mono">{label}</span>
      {hint && <span className="shrink-0 text-[10px] text-neutral-400">{hint}</span>}
    </button>
  );
}

type MentionCandidate = {
  kind: "ai" | "human";
  key: string;
  name: string;
  avatarUrl?: string;
};

/** Portal-rendered, composer-controlled list of matching mention targets. */
function AiMentionMenu({
  anchorRef,
  aiCandidates,
  peopleCandidates,
  activeIndex,
  onHover,
  onSelect,
  onClose,
}: {
  anchorRef: React.RefObject<HTMLTextAreaElement | null>;
  aiCandidates: readonly MentionCandidate[];
  peopleCandidates: readonly MentionCandidate[];
  activeIndex: number;
  onHover: (index: number) => void;
  onSelect: (candidate: MentionCandidate) => void;
  onClose: () => void;
}) {
  const menuRef = useRef<HTMLDivElement | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);
  const [position, setPosition] = useState({ top: -9999, left: -9999 });

  const positionMenu = useCallback(() => {
    const anchor = anchorRef.current;
    const menu = menuRef.current;
    if (!anchor || !menu) return;
    const rect = anchor.getBoundingClientRect();
    const width = 260;
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8));
    const above = rect.top - menu.offsetHeight - 4;
    setPosition({
      top: above >= 8 ? above : rect.bottom + 4,
      left,
    });
  }, [anchorRef]);

  useLayoutEffect(() => {
    positionMenu();
  }, [positionMenu, aiCandidates.length, peopleCandidates.length]);

  useEffect(() => {
    function onPointerDown(e: PointerEvent) {
      const target = e.target as Node;
      if (menuRef.current?.contains(target) || anchorRef.current?.contains(target)) return;
      onClose();
    }
    function onScroll(e: Event) {
      const target = e.target;
      if (target instanceof Node && menuRef.current?.contains(target)) return;
      onClose();
    }
    document.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("scroll", onScroll, true);
    window.addEventListener("resize", positionMenu);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("scroll", onScroll, true);
      window.removeEventListener("resize", positionMenu);
    };
  }, [anchorRef, onClose, positionMenu]);

  useEffect(() => {
    const item = listRef.current?.querySelector<HTMLElement>(
      `[data-mention-index="${activeIndex}"]`,
    );
    item?.scrollIntoView({ block: "nearest" });
  }, [activeIndex]);

  if (typeof document === "undefined") return null;

  const renderCandidate = (candidate: MentionCandidate, index: number) => (
    <button
      key={candidate.key}
      type="button"
      role="option"
      data-mention-index={index}
      aria-selected={index === activeIndex}
      onMouseEnter={() => onHover(index)}
      onMouseDown={(e) => e.preventDefault()}
      onClick={() => onSelect(candidate)}
      className={`flex w-full items-center gap-2 px-3 py-1.5 text-left transition-colors ${
        index === activeIndex
          ? "bg-neutral-100 dark:bg-neutral-800"
          : "hover:bg-neutral-50 dark:hover:bg-neutral-800/60"
      }`}
    >
      {candidate.avatarUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={candidate.avatarUrl}
          alt=""
          className="h-7 w-7 shrink-0 rounded-full object-cover"
        />
      ) : (
        <span
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${
            candidate.kind === "ai"
              ? "bg-gradient-to-br from-violet-400 to-indigo-500 text-white"
              : "bg-neutral-300 text-neutral-700 dark:bg-neutral-600 dark:text-neutral-200"
          }`}
        >
          {candidate.name[0]?.toUpperCase() ?? "?"}
        </span>
      )}
      <span className="truncate text-sm text-neutral-900 dark:text-neutral-100">
        {candidate.name}
      </span>
    </button>
  );

  return createPortal(
    <div
      ref={menuRef}
      style={{ top: position.top, left: position.left }}
      className="fixed z-50 w-[260px] overflow-hidden rounded-md border border-neutral-200 bg-white shadow-lg dark:border-neutral-700 dark:bg-neutral-900"
      role="dialog"
      aria-label="Mention a workspace member"
    >
      <div ref={listRef} className="max-h-[280px] overflow-y-auto py-1" role="listbox">
        {aiCandidates.length > 0 && (
          <>
            <p className="px-3 pb-1 pt-1 text-[11px] font-medium uppercase text-neutral-500 dark:text-neutral-400">
              AI users
            </p>
            {aiCandidates.map((candidate, index) => renderCandidate(candidate, index))}
          </>
        )}
        {peopleCandidates.length > 0 && (
          <>
            <p className="px-3 pb-1 pt-2 text-[11px] font-medium uppercase text-neutral-500 dark:text-neutral-400">
              People
            </p>
            {peopleCandidates.map((candidate, index) =>
              renderCandidate(candidate, aiCandidates.length + index),
            )}
          </>
        )}
      </div>
    </div>,
    document.body,
  );
}

/** Unique tool_bash command strings stored in a message's `toolCallsJson`. */
function bashCommandsIn(toolCallsJson: string): readonly string[] {
  let calls: ToolCallInfo[];
  try {
    calls = JSON.parse(toolCallsJson);
  } catch {
    return [];
  }
  if (!Array.isArray(calls)) return [];
  const commands: string[] = [];
  for (const tc of calls) {
    if (tc.name !== "tool_bash") continue;
    const command = bashCommandOf(tc);
    if (command && !commands.includes(command)) commands.push(command);
  }
  return commands;
}

type SpacetimeConnection = NonNullable<
  ReturnType<ReturnType<typeof useSpacetimeDB>["getConnection"]>
>;

// Minimal structural views of the SDK cache rows the drop handlers read
// imperatively (no standing per-thread subscriptions — see addPageAttachment).
type CachedPageRow = { id: bigint; title: string };
type CachedPageSnapshotRow = {
  pageId: bigint;
  content: string;
  snapshotAt: { microsSinceUnixEpoch: bigint };
};

/** Imperative `page` cache read. The sidebar keeps the whole page table
 * subscribed app-wide, so the row is already local — no per-thread
 * subscription needed just for the drop handlers. */
function findCachedPage(
  conn: SpacetimeConnection,
  pageId: bigint,
): CachedPageRow | undefined {
  const pages = (
    conn.db as unknown as { page: { iter(): Iterable<CachedPageRow> } }
  ).page;
  for (const p of pages.iter()) if (p.id === pageId) return p;
  return undefined;
}

function ConversationThread({
  conversation,
  messages,
  aiUser,
  allAiProfiles,
  onBack,
  activePageId,
}: {
  conversation: ConversationRow;
  messages: ConversationMessageRow[];
  aiUser: AiUserProfileRow | undefined;
  allAiProfiles: readonly AiUserProfileRow[];
  onBack: () => void;
  activePageId?: bigint;
}) {
  const aiIdentityHexes = useMemo(
    () => new Set(allAiProfiles.map((p) => p.identity.toHexString())),
    [allAiProfiles],
  );
  const sendMessage = useSendMessage();
  const sendUserMessage = useSendUserMessage();
  const conversationAttachments = useAttachmentsForConversation(conversation.id);
  // Hoisted per-message table subscriptions: one subscription each for
  // bridge commands, orcha jobs, and feedback instead of one per message /
  // tool call (a 60-message thread with tool calls held 300+ duplicate
  // whole-table subscriptions).
  const [allBridgeCommands] = useTable(tables.bridge_command);
  const conversationBridgeCommands = useMemo(
    () => allBridgeCommands.filter((c) => c.conversationId === conversation.id),
    [allBridgeCommands, conversation.id],
  );
  // Per-message bridge-command slices. The conversation-wide array above gets
  // a new identity whenever ANY bridge_command row changes, and handing it to
  // every visible message defeated AiMessageContent's memo. Match each
  // message's tool_bash command strings against the conversation's rows and
  // reuse the previous slice instance when its rows are unchanged (the SDK
  // cache replaces a row object only when that row changes), so only messages
  // whose commands actually changed get a new prop identity.
  const bashCommandCacheRef = useRef(
    new Map<bigint, { json: string; commands: readonly string[] }>(),
  );
  const prevBridgeSlicesRef = useRef(new Map<bigint, BridgeCommand[]>());
  const bridgeCommandsByMessage = useMemo(() => {
    const next = new Map<bigint, BridgeCommand[]>();
    if (conversationBridgeCommands.length > 0) {
      const rowsByCommand = new Map<string, BridgeCommand[]>();
      for (const c of conversationBridgeCommands) {
        const list = rowsByCommand.get(c.command);
        if (list) list.push(c);
        else rowsByCommand.set(c.command, [c]);
      }
      const bashCache = bashCommandCacheRef.current;
      const prev = prevBridgeSlicesRef.current;
      for (const msg of messages) {
        if (!msg.toolCallsJson) continue;
        let cached = bashCache.get(msg.id);
        if (!cached || cached.json !== msg.toolCallsJson) {
          cached = {
            json: msg.toolCallsJson,
            commands: bashCommandsIn(msg.toolCallsJson),
          };
          bashCache.set(msg.id, cached);
        }
        if (cached.commands.length === 0) continue;
        const slice: BridgeCommand[] = [];
        for (const command of cached.commands) {
          const rows = rowsByCommand.get(command);
          if (rows) slice.push(...rows);
        }
        if (slice.length === 0) continue;
        const before = prev.get(msg.id);
        next.set(
          msg.id,
          before &&
            before.length === slice.length &&
            before.every((row, i) => row === slice[i])
            ? before
            : slice,
        );
      }
    }
    prevBridgeSlicesRef.current = next;
    return next;
  }, [conversationBridgeCommands, messages]);
  const [allBridgeApprovals] = useTable(tables.bridge_approval);
  const conversationBridgeApprovals = useMemo<BridgeApproval[]>(
    () =>
      allBridgeApprovals
        .filter((approval) => approval.conversationId === conversation.id)
        .sort((a, b) =>
          Number(a.createdAt.microsSinceUnixEpoch - b.createdAt.microsSinceUnixEpoch),
        ),
    [allBridgeApprovals, conversation.id],
  );
  const { jobs: orchaJobs } = useOrchaJobs();
  const jobsById = useMemo(
    () => new Map(orchaJobs.map((j) => [j.id, j])),
    [orchaJobs],
  );
  const [allFeedback] = useTable(tables.message_feedback);
  const feedbackByMessage = useMemo(
    () => new Map(allFeedback.map((f) => [f.messageId, f])),
    [allFeedback],
  );
  // Automation events for generated-UI messages, hoisted like bridge_command
  // above: each StaticComponentTree provider used to mount its own full
  // automation_event_queue subscription, and the virtualizer re-downloaded
  // the grow-only queue on every scroll remount.
  const [automationEvents] = useTable(tables.automation_event_queue);
  const automationEventsByKey = useMemo(() => {
    const map = new Map<string, AutomationEventQueue>();
    for (const event of automationEvents) {
      if (event.idempotencyKey) map.set(event.idempotencyKey, event);
    }
    return map;
  }, [automationEvents]);

  // Bucketed once per attachment change — a per-message .filter() in the
  // message map is O(messages × attachments) on every render.
  const attachmentsByMessage = useMemo(() => {
    const map = new Map<bigint, ConversationAttachmentRow[]>();
    for (const a of conversationAttachments) {
      const list = map.get(a.messageId);
      if (list) list.push(a);
      else map.set(a.messageId, [a]);
    }
    return map;
  }, [conversationAttachments]);
  const closeConversation = useCloseConversation();
  const createConversation = useCreateConversation();
  const router = useRouter();
  const { identity, getConnection } = useSpacetimeDB();
  const { users: allHumanUsers } = useUsers();
  const [input, setInput] = useState("");
  const [caretIndex, setCaretIndex] = useState(0);
  const [mentionActiveIndex, setMentionActiveIndex] = useState(0);
  const [dismissedMentionKey, setDismissedMentionKey] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [pending, setPending] = useState<PendingAttachment[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const workspaceSlug = usePearWorkspaceSlug();
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const attachInputRef = useRef<HTMLInputElement | null>(null);
  // Windowed transcript (ticket 14386): only ~a viewport of messages mounts.
  // Heights vary (markdown, tool cards, attachments) so rows are measured;
  // tanstack's ResizeObserver re-measures the streaming message as it grows,
  // which keeps the pinned-to-bottom autoscroll math correct.
  const msgVirtualizer = useVirtualizer({
    count: messages.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => 96,
    overscan: 8,
  });
  const msgVirtualItems = msgVirtualizer.getVirtualItems();
  const msgPadTop =
    msgVirtualItems.length > 0 ? Math.max(0, msgVirtualItems[0].start) : 0;
  const msgPadBottom =
    msgVirtualItems.length > 0
      ? Math.max(
          0,
          msgVirtualizer.getTotalSize() -
            msgVirtualItems[msgVirtualItems.length - 1].end,
        )
      : 0;
  const isActive = conversation.status.tag === "Active";
  /** Fallback label / the thread's primary agent — used where no single message is in scope. */
  const aiName = aiUser?.displayName ?? "AI";
  /** Identity hex → profile, so each message can be credited to its real author. */
  const aiProfileByHex = useMemo(
    () => new Map(allAiProfiles.map((p) => [p.identity.toHexString(), p])),
    [allAiProfiles],
  );

  const lastMessage = messages[messages.length - 1];
  // After the identity refactor, both human and AI senders are tagged "User";
  // we tell them apart by Identity lookup against ai_user_profile.
  const lastSenderIdentity =
    lastMessage?.sender.tag === "User" ? lastMessage.sender.value : undefined;
  const lastSenderAiUser = lastSenderIdentity
    ? aiProfileByHex.get(lastSenderIdentity.toHexString())
    : undefined;
  const lastSenderIsHuman =
    lastMessage?.sender.tag === "User" && !lastSenderAiUser;
  const isAiActive =
    isActive &&
    lastMessage != null &&
    (lastSenderIsHuman ||
      (!!lastSenderAiUser &&
        lastMessage.status?.tag !== "Complete" &&
        lastMessage.status?.tag !== "Error"));

  // Id of the AI turn currently in flight (non-terminal AI message), if any.
  // A human message with a higher id arrived mid-turn and is therefore queued:
  // the worker defers it and picks it up when this turn finishes.
  const inFlightAiMsg = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      const m = messages[i];
      const sid = m.sender.tag === "User" ? m.sender.value : undefined;
      const isAi = sid != null && aiIdentityHexes.has(sid.toHexString());
      if (isAi && m.status?.tag !== "Complete" && m.status?.tag !== "Error") {
        return m;
      }
    }
    return undefined;
  }, [messages, aiIdentityHexes]);
  const inFlightAiMsgId = inFlightAiMsg?.id;
  const bridgeApprovalRenderKey = conversationBridgeApprovals
    .map((approval) => `${approval.id}:${approval.status.tag}`)
    .join(",");

  // Follow new output only when the reader is already at the bottom. Scrolling
  // someone back down while they are reading earlier messages — which a
  // streaming turn does on every token — makes the transcript unreadable
  // exactly when there is most to read. `pinnedToBottom` is sampled *before*
  // the DOM grows, so a mid-scroll reader stays put.
  const pinnedToBottom = useRef(true);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      // A small slack so "near enough" counts — landing a pixel short of the
      // end should not silently stop following.
      pinnedToBottom.current =
        el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    };
    onScroll();
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  useLayoutEffect(() => {
    if (!pinnedToBottom.current) return;
    // "smooth" restarts its easing animation on every streaming flush (~300ms)
    // and never settles, keeping the compositor busy for the whole turn — jump
    // instantly while a turn is in flight and save the eased scroll for
    // one-off arrivals in an idle thread.
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: isAiActive ? "auto" : "smooth",
    });
  }, [
    messages.length,
    isAiActive,
    lastMessage?.content,
    lastMessage?.thinking,
    lastMessage?.status?.tag,
    bridgeApprovalRenderKey,
  ]);

  // Opening a thread should always start at the newest message, regardless of
  // where the previous thread was scrolled to.
  useLayoutEffect(() => {
    pinnedToBottom.current = true;
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [conversation.id]);

  const uploading = pending.some(
    (a) => (a.kind === "image" || a.kind === "file") && a.status === "uploading",
  );
  const readySpecs = toAttachmentSpecs(pending);
  const canSend = (!!input.trim() || readySpecs.length > 0) && !sending && !uploading && isActive;
  const activeMention = useMemo(
    () => findActiveMentionQuery(input, caretIndex),
    [input, caretIndex],
  );
  const mentionCandidateGroups = useMemo(() => {
    if (!activeMention) {
      return {
        ai: [] as MentionCandidate[],
        people: [] as MentionCandidate[],
        all: [] as MentionCandidate[],
      };
    }
    const query = activeMention.query.toLocaleLowerCase();
    const ai: MentionCandidate[] = allAiProfiles
      .filter((profile) => profile.displayName.toLocaleLowerCase().includes(query))
      .map((profile) => ({
        kind: "ai",
        key: `ai:${profile.identity.toHexString()}`,
        name: profile.displayName,
        avatarUrl: optionStringFromRow(profile.avatarUrl) || undefined,
      }));
    const people: MentionCandidate[] = allHumanUsers
      .filter(
        (user) =>
          user.name.trim().length > 0 &&
          user.name.toLocaleLowerCase().includes(query),
      )
      .map((user) => ({
        kind: "human",
        key: `human:${user.identity.toHexString()}`,
        name: user.name,
      }));
    return { ai, people, all: [...ai, ...people] };
  }, [activeMention, allAiProfiles, allHumanUsers]);
  const mentionCandidates = mentionCandidateGroups.all;
  const mentionKey = activeMention
    ? `${activeMention.start}:${activeMention.end}:${caretIndex}:${activeMention.query}`
    : null;
  const mentionMenuOpen =
    mentionKey != null &&
    mentionKey !== dismissedMentionKey &&
    mentionCandidates.length > 0;

  useEffect(() => {
    setMentionActiveIndex(0);
  }, [mentionKey]);

  const selectMention = useCallback(
    (candidate: MentionCandidate) => {
      if (!activeMention) return;
      const inserted = insertMention(input, activeMention, candidate.name);
      setInput(inserted.value);
      setCaretIndex(inserted.caretIndex);
      setDismissedMentionKey(null);
      requestAnimationFrame(() => {
        textareaRef.current?.focus();
        textareaRef.current?.setSelectionRange(inserted.caretIndex, inserted.caretIndex);
      });
    },
    [activeMention, input],
  );

  function removePending(id: string) {
    setPending((prev) => {
      const att = prev.find((a) => a.id === id);
      if (att?.kind === "image") URL.revokeObjectURL(att.previewUrl);
      return prev.filter((a) => a.id !== id);
    });
  }

  /**
   * Queue dropped/pasted/picked files: images get an instant local thumbnail
   * and go to the model as vision; everything else becomes a file attachment
   * whose text the worker extracts. Both upload in the background.
   */
  function addFiles(files: File[]) {
    for (const file of files) {
      const id = newLocalId();
      if (isImageFile(file)) {
        setPending((prev) => [
          ...prev,
          {
            id,
            kind: "image",
            fileName: file.name || "image",
            mimeType: file.type || "image/png",
            previewUrl: URL.createObjectURL(file),
            status: "uploading",
          },
        ]);
      } else {
        setPending((prev) => [
          ...prev,
          {
            id,
            kind: "file",
            fileName: file.name || "file",
            mimeType: file.type || "application/octet-stream",
            sizeBytes: file.size,
            status: "uploading",
          },
        ]);
      }
      void uploadChatFile(workspaceSlug, file, conversation.id).then((objectKey) => {
        setPending((prev) =>
          prev.map((a) =>
            a.id === id && (a.kind === "image" || a.kind === "file")
              ? objectKey
                ? { ...a, objectKey, status: "ready" }
                : { ...a, status: "error" }
              : a,
          ),
        );
      });
    }
  }

  /** Resolve a sidebar page drop into a snapshot-at-drag context attachment.
   *
   * Neither source table is worth a standing thread-lifetime subscription:
   * `page` is already subscribed app-wide by the sidebar so the cache read is
   * free, and `page_snapshot` rows carry full serialized page content (two
   * rows per agent edit, never pruned) — hydrate just this page's snapshots
   * with a one-shot scoped subscription and release it once read. */
  async function addPageAttachment(payload: PageDragPayload) {
    let pageId: bigint;
    try {
      pageId = BigInt(payload.pageId);
    } catch {
      return;
    }
    if (pending.some((a) => a.kind === "page" && a.pageId === pageId)) return;
    const conn = getConnection();
    const page = conn ? findCachedPage(conn, pageId) : undefined;
    let snapshot = "";
    if (conn) {
      let snapshotSub: { unsubscribe: () => void } | null = null;
      try {
        await new Promise<void>((resolve, reject) => {
          snapshotSub = conn
            .subscriptionBuilder()
            .onApplied(() => resolve())
            .onError((ctx) => {
              const err = (ctx as { event?: unknown }).event;
              reject(err instanceof Error ? err : new Error("Snapshot subscription failed"));
            })
            .subscribe([`SELECT * FROM page_snapshot WHERE page_id = ${pageId}`]);
        });
        const snapshots = (
          conn.db as unknown as {
            page_snapshot: { iter(): Iterable<CachedPageSnapshotRow> };
          }
        ).page_snapshot;
        let latest: CachedPageSnapshotRow | undefined;
        for (const s of snapshots.iter()) {
          if (s.pageId !== pageId) continue;
          if (!latest || s.snapshotAt.microsSinceUnixEpoch > latest.snapshotAt.microsSinceUnixEpoch) {
            latest = s;
          }
        }
        snapshot = latest?.content ? extractTextFromBlockJson(latest.content) : "";
      } catch {
        // Snapshot hydration failed — attach with the title only.
      } finally {
        try {
          (snapshotSub as { unsubscribe: () => void } | null)?.unsubscribe();
        } catch {
          // Already torn down (e.g. disconnect mid-resolve) — nothing to release.
        }
      }
    }
    setPending((prev) =>
      prev.some((a) => a.kind === "page" && a.pageId === pageId)
        ? prev
        : [
            ...prev,
            {
              id: newLocalId(),
              kind: "page",
              pageId,
              title: page?.title ?? payload.title ?? "Untitled",
              snapshot,
            },
          ],
    );
  }

  function handleComposerDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const pagePayload = e.dataTransfer.getData(PAGE_DRAG_MIME);
    if (pagePayload) {
      try {
        void addPageAttachment(JSON.parse(pagePayload) as PageDragPayload);
      } catch { /* malformed drag payload */ }
      return;
    }
    if (e.dataTransfer.files.length > 0) {
      addFiles(Array.from(e.dataTransfer.files));
      return;
    }
    // Editor / native text selection drag → block-snapshot context.
    const text = e.dataTransfer.getData("text/plain").trim();
    if (text) {
      const conn = getConnection();
      const activePage =
        conn && activePageId != null ? findCachedPage(conn, activePageId) : undefined;
      setPending((prev) => [
        ...prev,
        {
          id: newLocalId(),
          kind: "blocks",
          pageId: activePageId,
          title: activePage?.title ?? "Selection",
          snapshot: text,
        },
      ]);
    }
  }

  function handlePaste(e: React.ClipboardEvent) {
    const files = Array.from(e.clipboardData.files);
    if (files.length > 0) {
      e.preventDefault();
      addFiles(files);
    }
  }

  async function handleSend() {
    if (!canSend) return;
    setSending(true);
    try {
      if (readySpecs.length > 0) {
        await sendUserMessage({
          conversationId: conversation.id,
          content: input.trim(),
          attachments: readySpecs,
        });
      } else {
        await sendMessage({
          conversationId: conversation.id,
          content: input.trim(),
          jobId: undefined,
          status: undefined,
          thinking: undefined,
          toolCallsJson: undefined,
          inputTokens: undefined,
          outputTokens: undefined,
          cacheCreationInputTokens: undefined,
          cacheReadInputTokens: undefined,
          linkedConversationId: undefined,
        });
      }
      setInput("");
      setCaretIndex(0);
      setPending((prev) => {
        for (const a of prev) {
          if (a.kind === "image") URL.revokeObjectURL(a.previewUrl);
        }
        return [];
      });
    } catch (err) {
      console.error("[AiPanel] Failed to send message", err);
    } finally {
      setSending(false);
    }
  }

  async function handleFork() {
    if (!activePageId || !aiUser) return;
    try {
      await createConversation({
        pageId: activePageId,
        participantIdentities: [aiUser.identity],
        blockAnchor: undefined,
      });
      router.push(`/workspace/${activePageId}`);
      onBack();
    } catch (err) {
      console.error("[AiPanel] Fork failed", err);
    }
  }

  return (
    <div className="flex flex-col h-full">
      {/* Thread header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 flex-shrink-0">
        <button
          onClick={onBack}
          className="p-1 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-neutral-800 dark:text-neutral-200 truncate">
            {aiName}
          </p>
          {aiUser && (
            <ConversationModelSwitcher conversation={conversation} aiUser={aiUser} />
          )}
        </div>
        {isActive && isAiActive && (
          <span className="flex items-center gap-1.5 shrink-0" title={`${aiName} is working`}>
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            <span className="text-xs text-amber-600 dark:text-amber-400">Working…</span>
          </span>
        )}
        {isActive && !isAiActive && (
          <span className="w-2 h-2 rounded-full bg-green-500 shrink-0" title="Active" />
        )}
        {!isActive && (
          <span className="text-xs text-neutral-400">Closed</span>
        )}
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 min-h-0">
        {messages.length === 0 && (
          <p className="text-xs text-neutral-400 text-center py-8">
            Conversation started — waiting for response…
          </p>
        )}
        {msgPadTop > 0 && <div aria-hidden="true" style={{ height: msgPadTop }} />}
        {msgVirtualItems.map((vi) => {
          const msg = messages[vi.index];
          // System messages render as their own thing; for User-tagged messages
          // we tell humans from AI users by membership in ai_user_profile.
          const senderIdentity = msg.sender.tag === "User" ? msg.sender.value : undefined;
          const isHuman =
            msg.sender.tag === "User" &&
            !aiIdentityHexes.has(senderIdentity!.toHexString());
          const isMe =
            isHuman &&
            identity &&
            senderIdentity!.toHexString() === identity.toHexString();
          const isQueued =
            isHuman && inFlightAiMsgId != null && msg.id > inFlightAiMsgId;
          // Attribute to whoever actually wrote it. A thread can hold several AI
          // users, so labelling every AI message with the conversation's first
          // participant credits the wrong agent as soon as a second one replies.
          const senderName = isHuman
            ? "User"
            : (senderIdentity &&
                aiProfileByHex.get(senderIdentity.toHexString())?.displayName) ??
              aiName;

          return (
            <div
              key={String(msg.id)}
              ref={msgVirtualizer.measureElement}
              data-index={vi.index}
              className={`flex pt-3 ${isMe ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-xl px-3 py-2 ${
                  isMe
                    ? "bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900"
                    : msg.status?.tag === "Error"
                      ? "bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-200 border border-red-200 dark:border-red-800/50"
                      : "bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200"
                }`}
              >
                {!isMe && (
                  <p className="text-xs font-medium mb-0.5 opacity-60">
                    {senderName}
                  </p>
                )}
                {isHuman ? (
                  <>
                    <MessageAttachments
                      attachments={attachmentsByMessage.get(msg.id) ?? NO_MESSAGE_ATTACHMENTS}
                    />
                    {msg.content && (
                      <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                    )}
                    {isQueued && (
                      <span className="mt-1 flex items-center gap-1 text-[10px] font-medium text-amber-600 dark:text-amber-400">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                        Queued · {aiName} will pick this up when the current turn finishes
                      </span>
                    )}
                  </>
                ) : (
                  <AiMessageContent
                    msg={msg}
                    aiName={senderName}
                    bridgeCommands={bridgeCommandsByMessage.get(msg.id) ?? NO_BRIDGE_COMMANDS}
                    automationEventsByKey={automationEventsByKey}
                    feedback={feedbackByMessage.get(msg.id)}
                  />
                )}
                {msg.jobId != null && jobsById.has(msg.jobId) && (
                  <InlineJobCard job={jobsById.get(msg.jobId)!} />
                )}
              </div>
              {msg.linkedConversationId != null && (
                <LinkedConversationCard linkedConversationId={msg.linkedConversationId} />
              )}
            </div>
          );
        })}
        {msgPadBottom > 0 && (
          <div aria-hidden="true" style={{ height: msgPadBottom }} />
        )}
        <HumanInputRequests conversationId={conversation.id} />
        {conversationBridgeApprovals.length > 0 && (
          <div className="space-y-2 pt-3" aria-live="polite">
            {conversationBridgeApprovals.map((approval) => (
              <BridgeApprovalCard key={String(approval.id)} approval={approval} />
            ))}
          </div>
        )}
      </div>

      {/* Context bar — shows what the AI user can see, plus pending
          write-access requests (which also arise in page-less AI DMs). */}
      {aiUser && (
        <ContextBar
          pageId={conversation.pageId}
          aiUserIdentity={aiUser.identity}
          conversationId={conversation.id}
          activePageId={activePageId}
          onFork={() => void handleFork()}
        />
      )}

      {/* Input */}
      {isActive ? (
        <div
          className={`flex-shrink-0 border-t p-3 transition-colors ${
            dragOver
              ? "border-blue-400 bg-blue-50/50 dark:bg-blue-950/20"
              : "border-neutral-200 dark:border-neutral-800"
          }`}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={(e) => {
            if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragOver(false);
          }}
          onDrop={handleComposerDrop}
        >
          <ComposerAttachments pending={pending} onRemove={removePending} />
          <div className="flex gap-2">
            {mentionMenuOpen && (
              <AiMentionMenu
                anchorRef={textareaRef}
                aiCandidates={mentionCandidateGroups.ai}
                peopleCandidates={mentionCandidateGroups.people}
                activeIndex={mentionActiveIndex}
                onHover={setMentionActiveIndex}
                onSelect={selectMention}
                onClose={() => setDismissedMentionKey(mentionKey)}
              />
            )}
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => {
                setInput(e.currentTarget.value);
                setCaretIndex(e.currentTarget.selectionStart ?? e.currentTarget.value.length);
                setDismissedMentionKey(null);
              }}
              onSelect={(e) =>
                setCaretIndex(e.currentTarget.selectionStart ?? e.currentTarget.value.length)
              }
              onPaste={handlePaste}
              placeholder={`Message ${aiName}…`}
              rows={2}
              className="flex-1 text-sm bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg px-3 py-2 text-neutral-800 dark:text-neutral-200 placeholder:text-neutral-400 resize-none outline-none focus:ring-1 focus:ring-neutral-400 dark:focus:ring-neutral-600 transition-shadow"
              onKeyDown={(e) => {
                if (mentionMenuOpen) {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setMentionActiveIndex((index) =>
                      (index + 1) % mentionCandidates.length,
                    );
                    return;
                  }
                  if (e.key === "ArrowUp") {
                    e.preventDefault();
                    setMentionActiveIndex((index) =>
                      (index - 1 + mentionCandidates.length) % mentionCandidates.length,
                    );
                    return;
                  }
                  if (e.key === "Enter" || e.key === "Tab") {
                    e.preventDefault();
                    const candidate = mentionCandidates[mentionActiveIndex];
                    if (candidate) selectMention(candidate);
                    return;
                  }
                  if (e.key === "Escape") {
                    e.preventDefault();
                    setDismissedMentionKey(mentionKey);
                    return;
                  }
                }
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void handleSend();
                }
              }}
            />
            <input
              ref={attachInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={(e) => {
                const files = Array.from(e.target.files ?? []);
                e.target.value = "";
                if (files.length > 0) addFiles(files);
              }}
            />
            <button
              type="button"
              onClick={() => attachInputRef.current?.click()}
              className="self-end p-2 rounded-lg text-neutral-500 hover:text-neutral-800 hover:bg-neutral-100 dark:text-neutral-400 dark:hover:text-neutral-100 dark:hover:bg-neutral-800 transition-colors"
              title="Attach files (or drop / paste them)"
              aria-label="Attach files"
            >
              <PaperclipIcon size={16} />
            </button>
            <button
              onClick={() => void handleSend()}
              disabled={!canSend}
              className="self-end p-2 rounded-lg bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 hover:bg-neutral-700 dark:hover:bg-neutral-300 disabled:opacity-40 transition-colors"
              title="Send (↵)"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-neutral-400">
              {isAiActive
                ? `${aiName} is working — new messages queue until the turn finishes`
                : "↵ send · ⇧↵ newline · drop files, images or pages"}
            </span>
            <div className="flex items-center gap-3">
              <HandoffPanel
                conversation={conversation}
                activePageId={activePageId}
                messages={messages}
                aiName={aiName}
              />
              <button
                onClick={() => closeConversation({ conversationId: conversation.id })}
                className="text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-shrink-0 border-t border-neutral-200 dark:border-neutral-800 px-4 py-3">
          <p className="text-xs text-neutral-400 text-center">This conversation is closed</p>
        </div>
      )}
    </div>
  );
}

// ── Handoff panel ────────────────────────────────────────────────────────────

type HandoffMode = "dm" | "invite" | "branch";

function HandoffPanel({
  conversation,
  activePageId,
  messages,
  aiName,
}: {
  conversation: ConversationRow;
  activePageId?: bigint;
  messages: ConversationMessageRow[];
  aiName: string;
}) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<HandoffMode | null>(null);
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const [inviteWarning, setInviteWarning] = useState(false);

  const { users } = useUsers();
  const { identity: myIdentity } = useSpacetimeDB();
  const { conversations: allConversations } = useConversations();
  const participants = useParticipantsForConversation(conversation.id);
  const findOrCreateDm = useFindOrCreateDm();
  const sendMessage = useSendMessage();
  const addParticipant = useAddConversationParticipant();
  const createConversation = useCreateConversation();

  const alreadyInThread = new Set(participants.map((p) => p.identity.toHexString()));
  const candidates = users.filter(
    (u) =>
      (!myIdentity || u.identity.toHexString() !== myIdentity.toHexString()) &&
      (u.name?.toLowerCase().includes(search.toLowerCase()) ||
        u.email?.toLowerCase().includes(search.toLowerCase()) ||
        !search),
  );

  function dmKey(a: string, b: string) {
    return a < b ? `${a}-${b}` : `${b}-${a}`;
  }

  function findExistingDm(otherIdentity: string) {
    if (!myIdentity) return undefined;
    const key = dmKey(myIdentity.toHexString(), otherIdentity);
    return allConversations.find((c) => c.canonicalKey === key);
  }

  async function handleSendToDm(user: (typeof users)[number]) {
    if (!myIdentity) return;
    setBusy(true);
    try {
      const lastAiMsg = [...messages].reverse().find(
        (m) => m.sender.tag === "User" && m.sender.value.toHexString() !== myIdentity.toHexString(),
      );
      const summary = lastAiMsg?.content ?? `Shared from conversation with ${aiName}`;
      const truncated = summary.length > 500 ? summary.slice(0, 497) + "…" : summary;
      const body = `From conversation with ${aiName}:\n\n${truncated}`;

      let dm = findExistingDm(user.identity.toHexString());
      if (!dm) {
        await findOrCreateDm({ otherIdentity: user.identity });
        // Wait for the DM to appear in subscription
        let tries = 0;
        while (!dm && tries < 20) {
          await new Promise((r) => setTimeout(r, 150));
          dm = findExistingDm(user.identity.toHexString());
          tries++;
        }
      }
      if (!dm) throw new Error("DM not found after creation");

      await sendMessage({
        conversationId: dm.id,
        content: body,
        jobId: undefined,
        status: undefined,
        thinking: undefined,
        toolCallsJson: undefined,
        inputTokens: undefined,
        outputTokens: undefined,
        cacheCreationInputTokens: undefined,
        cacheReadInputTokens: undefined,
        linkedConversationId: conversation.id,
      });
      setOpen(false);
      setMode(null);
    } catch (err) {
      console.error("[HandoffPanel] Send to DM failed", err);
    } finally {
      setBusy(false);
    }
  }

  async function handleInvite(user: (typeof users)[number]) {
    if (!inviteWarning) { setInviteWarning(true); return; }
    setBusy(true);
    try {
      await addParticipant({
        conversationId: conversation.id,
        identity: user.identity,
      });
      setOpen(false);
      setMode(null);
      setInviteWarning(false);
    } catch (err) {
      console.error("[HandoffPanel] Invite failed", err);
    } finally {
      setBusy(false);
    }
  }

  async function handleBranch(user: (typeof users)[number]) {
    const pageId = activePageId ?? conversation.pageId;
    if (!pageId) return;
    setBusy(true);
    try {
      await createConversation({
        pageId,
        participantIdentities: [user.identity],
        blockAnchor: undefined,
      });
      setOpen(false);
      setMode(null);
    } catch (err) {
      console.error("[HandoffPanel] Branch failed", err);
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="text-xs text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
      >
        Share →
      </button>
    );
  }

  return (
    <div className="flex flex-col gap-2 p-3 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-700 rounded-lg">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-neutral-700 dark:text-neutral-300">
          {mode === "dm" && "Send summary to…"}
          {mode === "invite" && "Invite to this thread…"}
          {mode === "branch" && "Start new thread with…"}
          {!mode && "Share with a person"}
        </span>
        <button
          onClick={() => { setOpen(false); setMode(null); setInviteWarning(false); }}
          className="text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300"
        >
          ×
        </button>
      </div>

      {!mode && (
        <div className="flex flex-col gap-1">
          <button
            onClick={() => setMode("dm")}
            className="text-left text-xs px-2 py-1.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
          >
            <span className="font-medium">→ Send summary to DM</span>
            <span className="block text-neutral-400 text-[10px]">Shares the last AI reply as a message</span>
          </button>
          <button
            onClick={() => setMode("invite")}
            className="text-left text-xs px-2 py-1.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
          >
            <span className="font-medium">+ Invite to this thread</span>
            <span className="block text-neutral-400 text-[10px]">They'll see all prior messages</span>
          </button>
          <button
            onClick={() => setMode("branch")}
            className="text-left text-xs px-2 py-1.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300"
          >
            <span className="font-medium">↗ New thread with…</span>
            <span className="block text-neutral-400 text-[10px]">Fresh conversation on this page</span>
          </button>
        </div>
      )}

      {mode && (
        <>
          {mode === "invite" && inviteWarning && (
            <p className="text-[10px] text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 rounded px-2 py-1.5">
              This person will see all prior messages in this thread.
            </p>
          )}
          <input
            autoFocus
            value={search}
            onChange={(e) => { setSearch(e.target.value); setInviteWarning(false); }}
            placeholder="Search members…"
            className="text-xs bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded px-2 py-1.5 outline-none focus:ring-1 focus:ring-neutral-400 dark:focus:ring-neutral-600 text-neutral-800 dark:text-neutral-200 placeholder:text-neutral-400"
          />
          <div className="flex flex-col gap-0.5 max-h-36 overflow-y-auto">
            {candidates.length === 0 && (
              <p className="text-xs text-neutral-400 py-2 text-center">No members found</p>
            )}
            {candidates.map((user) => {
              const displayName = user.name || user.email || user.identity.toHexString().slice(0, 8);
              const alreadyIn = alreadyInThread.has(user.identity.toHexString());
              return (
                <button
                  key={user.identity.toHexString()}
                  disabled={busy || (mode === "invite" && alreadyIn)}
                  onClick={() => {
                    if (mode === "dm") void handleSendToDm(user);
                    else if (mode === "invite") void handleInvite(user);
                    else if (mode === "branch") void handleBranch(user);
                  }}
                  className="text-left text-xs px-2 py-1.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-40 text-neutral-700 dark:text-neutral-300 flex items-center justify-between"
                >
                  <span className="truncate">{displayName}</span>
                  {mode === "invite" && alreadyIn && (
                    <span className="text-[10px] text-neutral-400 shrink-0 ml-2">already here</span>
                  )}
                  {mode === "invite" && !alreadyIn && inviteWarning && (
                    <span className="text-[10px] text-amber-600 shrink-0 ml-2">confirm ↵</span>
                  )}
                </button>
              );
            })}
          </div>
          <button
            onClick={() => { setMode(null); setInviteWarning(false); }}
            className="text-[10px] text-neutral-400 hover:text-neutral-600 text-left"
          >
            ← back
          </button>
        </>
      )}
    </div>
  );
}

function ConversationListItem({
  conversation,
  messages,
  aiUser,
  allAiProfiles,
  onClick,
}: {
  conversation: ConversationRow;
  messages: ConversationMessageRow[];
  aiUser: AiUserProfileRow | undefined;
  allAiProfiles: readonly AiUserProfileRow[];
  onClick: () => void;
}) {
  const aiIdentityHexes = useMemo(
    () => new Set(allAiProfiles.map((p) => p.identity.toHexString())),
    [allAiProfiles],
  );
  const lastMessage = messages[messages.length - 1];
  const isActive = conversation.status.tag === "Active";
  const lastSenderIsHuman =
    lastMessage?.sender.tag === "User" &&
    !aiIdentityHexes.has(lastMessage.sender.value.toHexString());

  return (
    <button
      onClick={onClick}
      className="w-full flex items-start gap-3 p-3 text-left rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors"
    >
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-400 to-indigo-500 flex items-center justify-center text-white text-xs font-bold shrink-0 mt-0.5">
        {(aiUser?.displayName ?? "?")[0].toUpperCase()}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-neutral-800 dark:text-neutral-200 truncate">
            {aiUser?.displayName ?? "AI User"}
          </span>
          {conversation.kind.tag !== "ContextThread" && (
            <span className="text-[9px] font-semibold uppercase px-1 py-px rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-500 dark:text-neutral-400 shrink-0">
              {conversation.kind.tag === "Dm" ? "DM"
                : conversation.kind.tag === "AiDm" ? "AI DM"
                : conversation.kind.tag === "GroupDm" ? "Group DM"
                : "Shared"}
            </span>
          )}
          {isActive && <span className="w-1.5 h-1.5 rounded-full bg-green-500 shrink-0" />}
        </div>
        {lastMessage && (
          <p className="text-xs text-neutral-400 truncate mt-0.5">
            {lastSenderIsHuman ? "You: " : ""}
            {lastMessage.content}
          </p>
        )}
        {!lastMessage && (
          <p className="text-xs text-neutral-400 italic mt-0.5">No messages yet</p>
        )}
      </div>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="14"
        height="14"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="shrink-0 mt-1.5 text-neutral-300 dark:text-neutral-600"
      >
        <polyline points="9 18 15 12 9 6" />
      </svg>
    </button>
  );
}

// ── Tab type ─────────────────────────────────────────────────────────────────

type PanelTab = "conversations" | "members";

/**
 * AI Users surfaced inside the right panel. This is the Phase A "Members"
 * tab — distinct from the workspace-wide MembersSettings (humans + admin
 * role) since AI users have their own provenance / harness story. Hosts a
 * compact directory that links to the full editor in Settings; the diff
 * review surface, auto-apply scope picker, and harness template selector
 * land here in subsequent phases.
 */
/** Per-AI-member activity/cost slice, indexed once in MembersTab. */
type AiMemberStats = {
  /** PostAgentEdit snapshots authored by this AI in the last 7 days. */
  proposed: number;
  /** Open denied-tool-call findings mentioning this AI. */
  denied: number;
  /** orcha_usage_event tokens (in + out) this calendar month (UTC). */
  usedTokens: number;
};

function MembersTab({ onOpenConversation }: { onOpenConversation: (id: bigint) => void }) {
  const { profiles } = useAiUserProfiles();
  const { users } = useUsers();
  const { identity: myIdentity } = useSpacetimeDB();
  const otherHumans = users.filter(
    (u) => !myIdentity || u.identity.toHexString() !== myIdentity.toHexString(),
  );
  // Retrospective / cost sources, subscribed once for the whole tab and
  // indexed per AI member in a single pass. Previously every AiMemberRow
  // mounted its own full-table page_snapshot / structural_sensor_finding /
  // orcha_usage_event subscriptions and re-scanned them unmemoized on every
  // render.
  const [snapshots] = useTable(tables.page_snapshot);
  const [findings] = useTable(tables.structural_sensor_finding);
  const [usage] = useTable(tables.orcha_usage_event);
  const statsByMember = useMemo(() => {
    const sevenDaysAgoMs = Date.now() - 7 * 24 * 3600 * 1000;
    const now = new Date();
    // Calendar-month rollover. Worker / billing might want a fiscal month
    // override later; for now align to UTC for determinism.
    const monthStartMs = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1);
    const stats = new Map<string, AiMemberStats>();
    const byHexPrefix: [string, AiMemberStats][] = [];
    const byAiUserId = new Map<bigint, AiMemberStats>();
    for (const profile of profiles) {
      const s: AiMemberStats = { proposed: 0, denied: 0, usedTokens: 0 };
      stats.set(profile.identity.toHexString(), s);
      byHexPrefix.push([profile.identity.toHexString().slice(0, 8), s]);
      byAiUserId.set(profile.aiUserId, s);
    }
    for (const s of snapshots) {
      if (s.snapshotType.tag !== "PostAgentEdit") continue;
      if (s.createdBy.tag !== "Agent") continue;
      if (Number(s.snapshotAt.microsSinceUnixEpoch / 1000n) < sevenDaysAgoMs) continue;
      const author = s.createdBy.value as string;
      for (const [prefix, stat] of byHexPrefix) {
        if (author.includes(prefix)) stat.proposed += 1;
      }
    }
    for (const f of findings) {
      if (f.resolvedAt) continue;
      if (f.sensorKind !== "denied_tool_calls") continue;
      for (const [prefix, stat] of byHexPrefix) {
        if (f.detailsJson.includes(prefix)) stat.denied += 1;
      }
    }
    for (const e of usage) {
      const stat = e.aiUserId != null ? byAiUserId.get(e.aiUserId) : undefined;
      if (!stat) continue;
      if (Number(e.createdAt.microsSinceUnixEpoch / 1000n) < monthStartMs) continue;
      stat.usedTokens += Number(e.tokensIn) + Number(e.tokensOut);
    }
    return stats;
  }, [profiles, snapshots, findings, usage]);

  return (
    <div className="px-2 py-2 space-y-1">
      {otherHumans.length > 0 && (
        <>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 px-2 py-1">
            People
          </p>
          {otherHumans.map((user) => (
            <HumanMemberRow
              key={user.identity.toHexString()}
              user={user}
              onOpenConversation={onOpenConversation}
            />
          ))}
        </>
      )}
      {profiles.length > 0 && (
        <>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-neutral-400 dark:text-neutral-500 px-2 py-1 mt-2">
            AI Users
          </p>
          {profiles.map((profile) => (
            <AiMemberRow
              key={profile.identity.toHexString()}
              profile={profile}
              stats={statsByMember.get(profile.identity.toHexString())}
              onOpenConversation={onOpenConversation}
            />
          ))}
        </>
      )}
      {profiles.length === 0 && otherHumans.length === 0 && (
        <div className="text-center py-10">
          <p className="text-sm text-neutral-400 dark:text-neutral-500">No members yet</p>
          <p className="text-xs text-neutral-300 dark:text-neutral-600 mt-1">
            Create AI users in Settings → AI Users
          </p>
        </div>
      )}
    </div>
  );
}

function HumanMemberRow({
  user,
  onOpenConversation,
}: {
  user: ReturnType<typeof useUsers>["users"][number];
  onOpenConversation: (id: bigint) => void;
}) {
  const { identity: myIdentity } = useSpacetimeDB();
  const findOrCreate = useFindOrCreateDm();
  const dm = useDmConversation(myIdentity, user.identity);
  const [pending, setPending] = useState(false);
  const displayName = user.name || user.email || user.identity.toHexString().slice(0, 8);

  useEffect(() => {
    if (pending && dm) {
      onOpenConversation(dm.id);
      setPending(false);
    }
  }, [pending, dm, onOpenConversation]);

  async function handleDm() {
    if (dm) { onOpenConversation(dm.id); return; }
    setPending(true);
    await findOrCreate({ otherIdentity: user.identity });
  }

  return (
    <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
      <div className="w-8 h-8 rounded-full bg-neutral-300 dark:bg-neutral-600 flex items-center justify-center text-neutral-700 dark:text-neutral-200 text-xs font-bold shrink-0">
        {displayName[0]?.toUpperCase() ?? "?"}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-neutral-800 dark:text-neutral-200 truncate">
          {displayName}
        </p>
        {user.email && user.name && (
          <p className="text-xs text-neutral-400 truncate">{user.email}</p>
        )}
      </div>
      <button
        onClick={() => void handleDm()}
        disabled={pending}
        className="shrink-0 text-xs px-2 py-1 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-40 transition-colors"
      >
        {pending ? "…" : "Message"}
      </button>
    </div>
  );
}

function AiMemberRow({
  profile,
  stats,
  onOpenConversation,
}: {
  profile: AiUserProfileRow;
  stats: AiMemberStats | undefined;
  onOpenConversation: (id: bigint) => void;
}) {
  const { identity: myIdentity } = useSpacetimeDB();
  const findOrCreate = useFindOrCreateAiDm();
  const dm = useDmConversation(myIdentity, profile.identity);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (pending && dm) {
      onOpenConversation(dm.id);
      setPending(false);
    }
  }, [pending, dm, onOpenConversation]);

  async function handleDm() {
    if (dm) { onOpenConversation(dm.id); return; }
    setPending(true);
    await findOrCreate({ aiIdentity: profile.identity });
  }

  return (
    <div className="flex flex-col gap-1 p-2 rounded-lg hover:bg-neutral-50 dark:hover:bg-neutral-800/50">
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-400 to-indigo-500 flex items-center justify-center text-white text-xs font-bold shrink-0 mt-0.5">
          {profile.displayName[0]?.toUpperCase() ?? "?"}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-neutral-800 dark:text-neutral-200 truncate">
            {profile.displayName}
          </p>
          <p className="text-xs text-neutral-400 truncate">
            {profile.providerName} · {profile.modelName}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => void handleDm()}
            disabled={pending}
            className="shrink-0 text-xs px-2 py-1 rounded bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700 disabled:opacity-40 transition-colors"
          >
            {pending ? "…" : "Message"}
          </button>
          <CostBadge usedTokens={stats?.usedTokens ?? 0} />
        </div>
      </div>
      <RetrospectiveRow proposed={stats?.proposed ?? 0} denied={stats?.denied ?? 0} />
    </div>
  );
}

/**
 * Steering loop retrospective. Shows last-7-day activity for an AI user:
 *   - Edits proposed (PostAgentEdit snapshots whose author is this AI user)
 *   - Open denied tool call findings for this AI user
 * The numbers are deliberately conservative: we only count what we can
 * derive from the relational substrate without instrumentation that
 * doesn't exist yet (no explicit "rejected" flag on snapshots). Counts are
 * computed once for all members in MembersTab's `statsByMember` pass.
 */
function RetrospectiveRow({ proposed, denied }: { proposed: number; denied: number }) {
  if (proposed === 0 && denied === 0) return null;
  return (
    <div className="flex items-center gap-2 pl-11 text-[10px] text-neutral-400 dark:text-neutral-500">
      {proposed > 0 && <span>{proposed} edits this week</span>}
      {denied > 0 && (
        <span className="text-amber-500">{denied} permission gaps</span>
      )}
    </div>
  );
}

/**
 * Compact monthly cost badge for an AI user (Phase A cost surface). Token
 * totals are computed once for all members in MembersTab's `statsByMember`
 * pass.
 *
 * The old `used / cap` variant is gone: `ai_user_config` is RLS-scoped to
 * the AI user's own identity (`AI_USER_CONFIG_FILTER` in ai/mod.rs), so
 * human clients always receive zero rows and `monthly_token_cap` was never
 * readable here — the badge only ever rendered the capless form while
 * paying for a full-table subscription per member row.
 */
function CostBadge({ usedTokens }: { usedTokens: number }) {
  return (
    <span className="text-[10px] text-neutral-400 dark:text-neutral-500 shrink-0">
      {formatTokens(usedTokens)} this month
    </span>
  );
}

function formatTokens(n: number): string {
  if (n < 1000) return `${n}`;
  if (n < 1_000_000) return `${(n / 1000).toFixed(1)}k`;
  return `${(n / 1_000_000).toFixed(1)}M`;
}

// ── Main panel ───────────────────────────────────────────────────────────────

interface AiPanelProps {
  pageId: bigint;
  onClose: () => void;
  /** If set, auto-open this conversation on mount. */
  openConversationId?: bigint;
}

/**
 * "+ New" — starts a fresh conversation with a chosen AI user and opens it.
 * Reducers don't return ids, so we snapshot the existing conversation ids, call
 * `createConversation`, then open the new one initiated by us once it arrives.
 */
function NewConversationButton({
  conversations,
  profiles,
  onOpen,
}: {
  conversations: readonly ConversationRow[];
  profiles: readonly AiUserProfileRow[];
  onOpen: (id: bigint) => void;
}) {
  const { identity } = useSpacetimeDB();
  const createConversation = useCreateConversation();
  const [open, setOpen] = useState(false);
  const pendingRef = useRef<Set<string> | null>(null);

  useEffect(() => {
    const existing = pendingRef.current;
    if (!existing || !identity) return;
    const meHex = identity.toHexString();
    const fresh = conversations
      .filter((c) => !existing.has(String(c.id)) && c.initiatedBy.toHexString() === meHex)
      .sort((a, b) => Number(b.id - a.id))[0];
    if (fresh) {
      pendingRef.current = null;
      setOpen(false);
      onOpen(fresh.id);
    }
  }, [conversations, identity, onOpen]);

  async function startWith(aiIdentity: Identity) {
    pendingRef.current = new Set(conversations.map((c) => String(c.id)));
    await createConversation({
      pageId: undefined,
      participantIdentities: [aiIdentity],
      blockAnchor: undefined,
    });
  }

  if (profiles.length === 0) return null;

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        title="New conversation"
        className="flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </svg>
        New
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-1 z-20 w-56 max-h-72 overflow-y-auto rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-900 shadow-lg py-1">
            <p className="px-3 py-1.5 text-[10px] uppercase tracking-wide text-neutral-400">
              Start a conversation with
            </p>
            {profiles.map((p) => (
              <button
                key={String(p.aiUserId)}
                onClick={() => void startWith(p.identity)}
                className="w-full flex items-center gap-2 px-3 py-1.5 text-left hover:bg-neutral-50 dark:hover:bg-neutral-800"
              >
                <span className="w-6 h-6 rounded-full bg-gradient-to-br from-violet-400 to-indigo-500 flex items-center justify-center text-white text-[10px] font-bold shrink-0">
                  {p.displayName[0]?.toUpperCase() ?? "?"}
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block text-sm text-neutral-800 dark:text-neutral-200 truncate">{p.displayName}</span>
                  <span className="block text-[11px] text-neutral-400 truncate">{p.modelName}</span>
                </span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export function AiPanel({ pageId, onClose, openConversationId }: AiPanelProps) {
  const { identity } = useSpacetimeDB();
  const { conversations: allConversations } = useConversations();
  const allMessages = useConversationMessages();
  const allParticipants = useConversationParticipants();
  const { profiles: allAiProfiles } = useAiUserProfiles();

  // Keep one subscription per live conversation table mounted for the panel's
  // whole lifetime. Previously every list row subscribed to the entire message,
  // participant, and AI-profile tables; selecting a row tore all of those down
  // while mounting replacement subscriptions for the thread. That transition
  // could leave the SDK cache without a live query until a page refresh.
  const conversations = useMemo(() => {
    if (!identity) return [] as ConversationRow[];
    const meHex = identity.toHexString();
    const myConversationIds = new Set(
      allParticipants
        .filter((participant) =>
          participant.identity.toHexString() === meHex && !participant.leftAt
        )
        .map((participant) => String(participant.conversationId)),
    );
    return allConversations
      .filter((conversation) => myConversationIds.has(String(conversation.id)))
      .sort((a, b) =>
        Number(b.updatedAt.microsSinceUnixEpoch - a.updatedAt.microsSinceUnixEpoch)
      );
  }, [allConversations, allParticipants, identity]);

  const messagesByConversation = useMemo(() => {
    const grouped = new Map<bigint, ConversationMessageRow[]>();
    for (const message of allMessages) {
      if (!isVisibleConversationMessage(message)) continue;
      const existing = grouped.get(message.conversationId);
      if (existing) existing.push(message);
      else grouped.set(message.conversationId, [message]);
    }
    for (const messages of grouped.values()) {
      messages.sort((a, b) =>
        Number(a.createdAt.microsSinceUnixEpoch - b.createdAt.microsSinceUnixEpoch)
      );
    }
    return grouped;
  }, [allMessages]);

  const aiUserByConversation = useMemo(() => {
    const profileByIdentity = new Map(
      allAiProfiles.map((profile) => [profile.identity.toHexString(), profile]),
    );
    const grouped = new Map<bigint, AiUserProfileRow>();
    for (const participant of allParticipants) {
      if (grouped.has(participant.conversationId)) continue;
      const profile = profileByIdentity.get(participant.identity.toHexString());
      if (profile) grouped.set(participant.conversationId, profile);
    }
    return grouped;
  }, [allAiProfiles, allParticipants]);

  const [tab, setTab] = useState<PanelTab>("conversations");
  const [selectedConvId, setSelectedConvId] = useState<bigint | null>(
    openConversationId ?? null
  );

  useEffect(() => {
    if (openConversationId == null) return;
    setTab("conversations");
    setSelectedConvId(openConversationId);
  }, [openConversationId]);

  const selectedConv = selectedConvId
    ? allConversations.find((c) => c.id === selectedConvId)
    : null;

  const hasActiveConv = conversations.some((c) => c.status.tag === "Active");

  if (selectedConv) {
    return (
      <div className="flex flex-col h-full bg-white dark:bg-neutral-950">
        <ConversationThread
          conversation={selectedConv}
          messages={messagesByConversation.get(selectedConv.id) ?? NO_CONVERSATION_MESSAGES}
          aiUser={aiUserByConversation.get(selectedConv.id)}
          allAiProfiles={allAiProfiles}
          onBack={() => setSelectedConvId(null)}
          activePageId={pageId}
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-neutral-950">
      {/* Header with tabs */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 flex-shrink-0">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setTab("conversations")}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
              tab === "conversations"
                ? "bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200"
                : "text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300"
            }`}
          >
            Conversations
            {hasActiveConv && (
              <span className="ml-1.5 w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
            )}
          </button>
          <button
            onClick={() => setTab("members")}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
              tab === "members"
                ? "bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200"
                : "text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300"
            }`}
          >
            Members
          </button>
        </div>
        <div className="flex items-center gap-1">
        <NewConversationButton
          conversations={allConversations}
          profiles={allAiProfiles}
          onOpen={(id) => {
            setTab("conversations");
            setSelectedConvId(id);
          }}
        />
        <button
          onClick={onClose}
          className="p-1 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
        </div>
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto min-h-0">
        {tab === "conversations" && (
          <div className="px-2 py-2">
            {conversations.length === 0 && (
              <div className="text-center py-10">
                <p className="text-sm text-neutral-400 dark:text-neutral-500">
                  No conversations yet
                </p>
                <p className="text-xs text-neutral-300 dark:text-neutral-600 mt-1">
                  Type <span className="font-mono">@</span> in the editor to mention an AI user
                </p>
              </div>
            )}
            {conversations.map((conv) => (
              <ConversationListItem
                key={String(conv.id)}
                conversation={conv}
                messages={messagesByConversation.get(conv.id) ?? NO_CONVERSATION_MESSAGES}
                aiUser={aiUserByConversation.get(conv.id)}
                allAiProfiles={allAiProfiles}
                onClick={() => setSelectedConvId(conv.id)}
              />
            ))}
          </div>
        )}

        {tab === "members" && <MembersTab onOpenConversation={(id) => { setTab("conversations"); setSelectedConvId(id); }} />}
      </div>
    </div>
  );
}
